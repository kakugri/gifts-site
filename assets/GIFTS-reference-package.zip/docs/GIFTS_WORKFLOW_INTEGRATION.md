# GIFTS Workflow Integration Guide

This guide explains how a security team or technical reviewer can use the current `GIFTS` reference package in a practical workflow.

## Integration posture

`GIFTS` should currently be integrated as an offline or sidecar analysis tool.

It is not yet a production inline control, SIEM replacement, or automatic enforcement system.

The safest first integration pattern is:

1. export identity events from an existing source;
2. convert them into the `GIFTS` session contract;
3. validate the contract file;
4. score sessions into workflow findings;
5. route the highest-risk sessions into analyst review, identity-control review, or incident reconstruction.

## Basic workflow

```bash
python3 -m gifts \
  --convert-cloudtrail-jsonl examples/cloudtrail_like_events.jsonl \
  --output /tmp/gifts_sessions.jsonl

python3 -m gifts --validate-session-file /tmp/gifts_sessions.jsonl

python3 -m gifts \
  --score-session-file /tmp/gifts_sessions.jsonl \
  --findings-path /tmp/gifts_findings.jsonl \
  --findings-csv /tmp/gifts_findings.csv \
  --workflow-report-path /tmp/gifts_workflow_report.md
```

## Where GIFTS can fit

### SOC triage

Use `GIFTS` after logs have already been collected.

Best current fit:

- batch-score recent identity sessions;
- sort by `risk_score`;
- review `critical` and `high` sessions first;
- preserve the markdown report as triage context.

### Identity-control review

Use `GIFTS` during weekly or monthly review of identity posture.

Best current fit:

- identify sessions involving privilege changes, logging-control actions, external source categories, or unknown user agents;
- compare findings with approved change records;
- use repeated patterns to tune identity policies or alerting rules.

### Incident reconstruction support

Use `GIFTS` after a suspicious identity event or partial logging gap.

Best current fit:

- sessionize the known events;
- represent intentionally missing events with `{"observed": false}`;
- use findings and the report to frame analyst questions;
- treat missing-event reconstruction as a hypothesis aid, not final truth.

### Red-team or tabletop evaluation

Use `GIFTS` to test whether identity workflows leave detectable traces.

Best current fit:

- model known attack chains as session examples;
- check whether risky sequences are surfaced as higher-risk findings;
- use output JSONL as repeatable evidence for control evaluation.

## Current finding outputs

The scoring workflow can emit:

- JSONL findings for automation or downstream tooling;
- CSV findings for spreadsheet review or SIEM-style import;
- markdown report for analyst review.

Each finding includes:

- `session_id`;
- `risk_score`;
- `risk_level`;
- identity context;
- suspicious actions;
- workflow signals;
- recommended analyst actions;
- normalized event details.

## Integration boundaries

The current workflow scoring layer is intentionally transparent and conservative.

It is based on:

- sensitive identity, logging, data, and infrastructure actions;
- missing or blacked-out event slots;
- external or Tor-like source categories;
- suspicious principal labels in example data;
- privilege-change and resource-creation sequences.

It does not yet provide:

- production-calibrated model thresholds;
- environment-specific baselines;
- saved deep-model artifacts for arbitrary tenant logs;
- automatic enforcement;
- direct SIEM, SOAR, or ticketing API pushes.

## Recommended first pilot

The cleanest first pilot is a small offline workflow:

1. choose `20` to `100` non-sensitive historical identity sessions;
2. map them into the `GIFTS` session contract;
3. run scoring;
4. review only `high` and `critical` sessions;
5. record whether the findings matched known security, change-management, or incident context.

That pilot would answer the most important adoption question:

- does the `GIFTS` representation help analysts ask better identity-security questions?

## Safe language

Use:

- `workflow findings`;
- `triage support`;
- `identity-session scoring`;
- `offline evaluation`;
- `reconstruction hypotheses`.

Avoid:

- `production detector`;
- `automatic incident verdict`;
- `enterprise-ready SIEM integration`;
- `confirmed forensic reconstruction`.

## Bottom line

The practical integration story for `GIFTS` is now:

- bring identity sessions into a stable contract;
- score those sessions into analyst-readable findings;
- export the results into existing review workflows;
- use the outputs to support triage, review, and investigation rather than replace them.
