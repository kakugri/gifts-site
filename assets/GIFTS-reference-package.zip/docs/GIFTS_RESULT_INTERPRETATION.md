# How To Interpret GIFTS Results

This note is a practical reading guide for the outputs produced by the `GIFTS` reference package.

It is intentionally simple.

The goal is to help reviewers understand what the current prototype outputs mean and what they do **not** mean.

## First principle

`GIFTS` currently produces prototype evaluation outputs.

Those outputs are useful for:

- technical review
- method understanding
- adaptation discussion
- comparative experimentation

They are **not** by themselves proof of production readiness or field deployment quality.

## Reading the fast-path metrics

The fast path is the `IsolationForest` baseline screen.

Useful fields:

- `ROC-AUC`
- `PR-AUC`
- `FPR@TPR=0.95`
- confusion counts: `TP`, `FN`, `FP`, `TN`

How to read them:

- higher `ROC-AUC` is better
- higher `PR-AUC` is better
- lower `FPR@TPR=0.95` is better

What it means:

- this stage is a quick anomaly screen
- it is useful for routing suspicious sessions toward deeper analysis

What it does **not** mean:

- a good fast-path score does not mean the whole system is complete
- a poor fast-path score does not invalidate the deeper method by itself

## Reading the deep-path metrics

The deep path is the geodesic-plus-healing trust detector.

Useful fields:

- `ROC-AUC`
- `PR-AUC`
- `FPR@TPR=0.95`
- `threshold_tpr95`
- `per_attack`

How to read them:

- compare them against the fast-path metrics
- if the deep path reduces false positives while maintaining high recall, that is generally a useful sign

What it means:

- the deeper scoring stage is trying to use manifold structure and healing distance to separate normal from suspicious behavior more intelligently

What it does **not** mean:

- it does not establish real-world detection quality across arbitrary environments
- it does not yet replace a full benchmark program or deployment evaluation

## Reading the forensic reconstruction output

The forensic report and the `forensic_demo` JSON block are best read as:

- a multi-hypothesis reconstruction example for missing or blacked-out action segments

The most useful fields are:

- `observed_actions`
- `ground_truth_full_actions`
- `consensus_actions`
- `ground_truth_missing_actions`
- `consensus_missing_actions`
- `uncertainty_by_index`
- `hypothesis_summaries`

How to read them:

- `observed_actions` shows what the model was allowed to see
- `ground_truth_full_actions` shows the full synthetic truth for evaluation
- `consensus_actions` is the current recommended reconstruction
- `uncertainty_by_index` shows where the reconstruction is more or less confident

What `uncertainty` means here:

- lower uncertainty suggests stronger agreement among candidate hypotheses
- higher uncertainty suggests the missing slot is more ambiguous under the current model

What it does **not** mean:

- the consensus result is not guaranteed ground truth in a real environment
- the current prototype is still a reconstruction aid, not a final forensic authority

## Reading per-attack results

The `per_attack` block is useful because aggregate metrics can hide uneven behavior.

How to read it:

- look for whether recall holds across different attack families
- treat uneven recall as a sign that the prototype may generalize better to some behaviors than others

## Best current use of the results

The strongest use of current `GIFTS` outputs is:

- compare runs
- inspect reconstruction behavior
- evaluate whether adaptation changes improve or degrade prototype behavior
- explain the method to technically capable reviewers

## Overclaim guardrails

Avoid describing current outputs as:

- proof of enterprise-grade detection quality
- proof of deployment readiness
- proof that the reconstructed action sequence is definitely what happened

Safer language is:

- prototype evaluation results
- reference-package metrics
- reconstruction hypotheses
- early technical evidence of method behavior

## Bottom line

At this stage, good `GIFTS` results should be interpreted as:

- encouraging evidence that the public method behaves coherently
- a useful basis for review and adaptation
- a stronger public technical artifact than a paper alone

They should not yet be interpreted as:

- final operational truth
- deployment certification
- a production-quality benchmark conclusion
