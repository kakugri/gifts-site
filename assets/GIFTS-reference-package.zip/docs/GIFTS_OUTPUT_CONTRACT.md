# GIFTS Output Contract

This document defines the current public output contract for the `GIFTS` reference package.

## Why this contract exists

The public input contract explains how data gets into `GIFTS`.

This output contract explains what comes out of a run and how outside reviewers should interpret those artifacts.

## Current output level

This is a `reference-package` output contract.

It is meant to support:

- technical review
- reproducibility
- adaptation discussions
- early collaborator understanding

It is not yet a production-grade guarantee for long-term compatibility.

## Current output artifacts

The public package currently produces up to three output types:

### 1. Console evaluation output

This includes:

- fast-path baseline metrics
- deep-path trust-detector metrics
- selected reconstruction preview text

This is useful for local review, but it is not the best machine-readable artifact.

### 2. Markdown forensic report

Default path:

- `GIFTS_Forensic_Report_Inpaint.md`

Purpose:

- show a blacked-out or missing segment reconstruction example
- compare observed actions, ground truth, and reconstructed actions
- summarize competing hypotheses and uncertainty

Best use:

- human review
- public technical illustration
- prototype walkthroughs

### 3. JSON run summary

Optional path:

- provided through `--summary-path`

Purpose:

- capture a stable machine-readable summary of the run
- preserve aggregate metrics and reconstruction outputs in a structured form

Best use:

- reproducibility
- adaptation testing
- later comparison across runs
- downstream tooling or visualization experiments

## JSON run summary schema

The summary file currently uses:

- `schema_version = gifts-output-summary-v1`

Top-level structure:

```json
{
  "schema_version": "gifts-output-summary-v1",
  "package_role": "reference-implementation",
  "runtime": {},
  "config": {},
  "dataset": {},
  "fast_path_metrics": {},
  "deep_path_metrics": {},
  "forensic_demo": {}
}
```

## Runtime block

Example fields:

- `device`
- `report_path`
- `summary_path`

Purpose:

- show where the run executed
- preserve artifact paths

## Config block

Example fields:

- `batch_size`
- `epochs_mlm`
- `epochs_diff`
- `epochs_dec`
- `diff_t`
- `requested_heal_start_t`
- `effective_heal_start_t`
- `trust_geo_w`
- `trust_heal_w`
- `max_events`
- `tokens_per_event`
- `latent_dim`
- `embedding_dim`

Purpose:

- preserve the experimental settings that shaped the run
- distinguish between the requested healing start and the effective value actually used after clamping to the current diffusion depth

## Dataset block

Example fields:

- `train_sessions`
- `test_sessions`
- `vocab_size`
- `action_vocab_size`

Purpose:

- preserve dataset scale and basic model-context size

## Fast-path metrics block

This summarizes the `IsolationForest` baseline stage.

Example fields:

- `roc_auc`
- `pr_auc`
- `fpr_at_tpr95`
- `threshold_tpr95`
- `tp`
- `fn`
- `fp`
- `tn`
- `per_attack`
- `n_flagged`
- `n_eval`

Purpose:

- capture how well the fast anomaly-screening stage performed

## Deep-path metrics block

This summarizes the geodesic-plus-healing trust detector.

Example fields:

- `roc_auc`
- `pr_auc`
- `fpr_at_tpr95`
- `threshold_tpr95`
- `tp`
- `fn`
- `fp`
- `tn`
- `per_attack`
- optional trust-sweep fields such as `sweep_best` and `sweep_top5`

Purpose:

- capture the performance of the deeper scoring stage used after fast-path routing

## Forensic demo block

This summarizes the selected reconstruction example.

Example fields:

- `attack_type`
- `label`
- `blackout_interval`
- `hypotheses_generated`
- `observed_actions`
- `ground_truth_full_actions`
- `most_plausible_actions`
- `most_suspicious_actions`
- `consensus_actions`
- `missing_indices`
- `ground_truth_missing_actions`
- `consensus_missing_actions`
- `uncertainty_by_index`
- `vote_table_by_index`
- `hypothesis_summaries`

Purpose:

- preserve the reconstruction example in a structured way rather than only in markdown prose

## Commands

Generate a JSON run summary:

```bash
python3 -m gifts \
  --report-path /tmp/GIFTS_report.md \
  --summary-path /tmp/GIFTS_summary.json
```

## Example files

See:

- `examples/GIFTS_output_report_example.md`
- `examples/GIFTS_output_summary_example.json`

## Current best interpretation

The current output contract makes `GIFTS` more legible to outside readers because it shows:

- what a run produces
- which outputs are human-readable versus machine-readable
- how a technically capable reviewer could compare runs or inspect one reconstruction case

That is the right next step for a public reference package.
