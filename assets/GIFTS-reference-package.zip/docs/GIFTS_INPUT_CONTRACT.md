# GIFTS Input Contract

This document defines the current public input contract for adapting external identity-event data into the `GIFTS` reference package.

## Why this contract exists

The current public `GIFTS` pipeline was first built around synthetic `CloudTrail`-style sessions.

To make adaptation more concrete, the public package now uses a stable intermediate format:

- a `sessionized JSON` or `JSONL` contract

That contract is the clean handoff between:

- raw provider-specific event logs

and:

- the internal sequence representation used by `GIFTS`

## Current contract level

This is a `reference-package` contract.

It is meant to make adaptation and experimentation easier.

It is not yet a long-term production compatibility guarantee.

## File formats

The validator accepts:

- `.jsonl` where each line is one session object
- `.json` containing either one session object or a list of session objects

## Session object

Each session object should look like:

```json
{
  "session_id": "session-normal-001",
  "label": "normal",
  "attack_type": "normal",
  "events": [
    {
      "observed": true,
      "action": "sts:AssumeRole",
      "source": "src:sts.amazonaws.com",
      "principal_type": "ptype:AssumedRole",
      "principal_arn": "parn:arn:aws:iam::111122223333:role/dev_role",
      "ip": "ip:corp",
      "region": "region:us-east-1",
      "ua": "ua:awscli",
      "resource": "res:arn:aws:iam::111122223333:role/dev_role",
      "time_bin": "time:t00"
    }
  ]
}
```

## Required session fields

- `session_id`
- `events`

## Label values

Supported labels are:

- `normal`
- `benign`
- `attack`
- `anomalous`
- `suspicious`
- `unknown`

## Event object

### Visible event

If the event is visible or observed, it must include:

- `action`
- `source`
- `principal_type`
- `principal_arn`
- `ip`
- `region`
- `ua`
- `resource`

Optional:

- `time_bin`
- `observed`

### Missing or blacked-out event

If the event is intentionally unknown or blacked out, the minimal representation is:

```json
{
  "observed": false
}
```

That will be mapped internally to the current blackout placeholder used by the prototype.

## Field conventions

The current contract prefers these prefixes:

- `source`: `src:...`
- `principal_type`: `ptype:...`
- `principal_arn`: `parn:...`
- `ip`: `ip:...`
- `region`: `region:...`
- `ua`: `ua:...`
- `resource`: `res:...`
- `time_bin`: `time:...`

The validator normalizes missing prefixes where possible.

## Current prototype limits

The public prototype currently uses a fixed event horizon of:

- `MAX_EVENTS = 10`

If a session contains more than `10` events, the validator accepts it but warns that the current prototype uses only the first `10`.

## CloudTrail-like adaptation path

The package also includes a simple reference adapter for `CloudTrail`-like JSONL records.

That raw-record path expects each line to contain at least:

- `session_id`
- `eventName`
- `eventSource`
- `userIdentity`
- `sourceIPAddress`
- `awsRegion`
- `userAgent`

Optional but useful:

- `resource`
- `resources`
- `event_index`
- `eventTime`
- `label`
- `attack_type`
- `time_bin`

The adapter then groups those records by `session_id` and converts them into the session contract above.

## Example files

See:

- `examples/cloudtrail_like_events.jsonl`
- `examples/gifts_session_contract_example.jsonl`
- `examples/README.md`

## Validation command

Validate a session-contract file:

```bash
python3 -m gifts --validate-session-file examples/gifts_session_contract_example.jsonl
```

## Scoring command

After a session-contract file validates, score it into workflow findings:

```bash
python3 -m gifts \
  --score-session-file examples/gifts_session_contract_example.jsonl \
  --findings-path /tmp/gifts_findings.jsonl \
  --findings-csv /tmp/gifts_findings.csv \
  --workflow-report-path /tmp/gifts_workflow_report.md
```

## Conversion command

Convert CloudTrail-like JSONL records into the GIFTS session contract:

```bash
python3 -m gifts \
  --convert-cloudtrail-jsonl examples/cloudtrail_like_events.jsonl \
  --output /tmp/gifts_sessions.jsonl
```

Then validate the result:

```bash
python3 -m gifts --validate-session-file /tmp/gifts_sessions.jsonl
```

## Current best interpretation

This contract makes `GIFTS` more adoptable by giving outside readers and collaborators a concrete way to understand:

- what shape input data should take
- how raw identity events can be adapted into GIFTS
- how adapted sessions can become analyst-readable workflow findings
- where the current prototype boundary still is

That is the right next step for a public reference package.
