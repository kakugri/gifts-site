from __future__ import annotations

import ipaddress
import json
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .config import MAX_EVENTS
from .data import Event, blackout_event


LABEL_MAP = {
    "normal": 0,
    "benign": 0,
    "attack": 1,
    "anomalous": 1,
    "suspicious": 1,
    "unknown": -1,
}

REQUIRED_VISIBLE_EVENT_FIELDS = (
    "action",
    "source",
    "principal_type",
    "principal_arn",
    "ip",
    "region",
    "ua",
    "resource",
)


@dataclass
class ValidationResult:
    path: Path
    session_count: int
    errors: list[str]
    warnings: list[str]

    @property
    def is_valid(self) -> bool:
        return not self.errors


def _load_records(path: str | Path) -> list[dict[str, Any]]:
    file_path = Path(path)
    text = file_path.read_text(encoding="utf-8")

    if file_path.suffix.lower() == ".jsonl":
        records = []
        for lineno, line in enumerate(text.splitlines(), start=1):
            line = line.strip()
            if not line:
                continue
            obj = json.loads(line)
            if not isinstance(obj, dict):
                raise ValueError(f"Line {lineno} in {file_path} is not a JSON object.")
            records.append(obj)
        return records

    data = json.loads(text)
    if isinstance(data, dict):
        return [data]
    if isinstance(data, list):
        if not all(isinstance(item, dict) for item in data):
            raise ValueError(f"{file_path} must contain JSON objects only.")
        return data
    raise ValueError(f"{file_path} must contain a JSON object, array, or JSONL objects.")


def _dump_jsonl(records: list[dict[str, Any]], path: str | Path) -> Path:
    output_path = Path(path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    with output_path.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(record, sort_keys=True))
            handle.write("\n")
    return output_path


def _ensure_prefixed(value: Any, prefix: str, fallback: str) -> str:
    raw = str(value).strip() if value is not None else ""
    if not raw:
        raw = fallback
    if raw.startswith(prefix):
        return raw
    return f"{prefix}{raw}"


def _normalize_time_bin(value: Any, event_index: int) -> str:
    raw = str(value).strip() if value is not None else ""
    if not raw:
        return f"time:t{event_index:02d}"
    if raw.startswith("time:"):
        return raw
    return f"time:{raw}"


def event_to_contract_dict(event: Event) -> dict[str, Any]:
    if event.action == "<BLACKOUT>":
        return {"observed": False}

    return {
        "observed": True,
        "action": event.action,
        "source": event.source,
        "principal_type": event.principal_type,
        "principal_arn": event.principal_arn,
        "ip": event.ip,
        "region": event.region,
        "ua": event.ua,
        "resource": event.resource,
        "time_bin": event.time_bin,
    }


def normalize_contract_event(record: dict[str, Any], event_index: int) -> Event:
    observed = record.get("observed", True)
    if observed is False:
        return blackout_event()

    missing = [key for key in REQUIRED_VISIBLE_EVENT_FIELDS if not str(record.get(key, "")).strip()]
    if missing:
        raise ValueError(f"Visible event is missing required fields: {', '.join(missing)}")

    return Event(
        action=str(record["action"]).strip(),
        source=_ensure_prefixed(record["source"], "src:", "unknown.amazonaws.com"),
        principal_type=_ensure_prefixed(record["principal_type"], "ptype:", "Unknown"),
        principal_arn=_ensure_prefixed(record["principal_arn"], "parn:", "unknown"),
        ip=_ensure_prefixed(record["ip"], "ip:", "unknown"),
        region=_ensure_prefixed(record["region"], "region:", "unknown"),
        ua=_ensure_prefixed(record["ua"], "ua:", "unknown"),
        resource=_ensure_prefixed(record["resource"], "res:", "unknown"),
        time_bin=_normalize_time_bin(record.get("time_bin"), event_index),
    )


def normalize_contract_session(record: dict[str, Any]) -> dict[str, Any]:
    session_id = str(record.get("session_id", "")).strip()
    if not session_id:
        raise ValueError("Session is missing a non-empty session_id.")

    events = record.get("events")
    if not isinstance(events, list) or not events:
        raise ValueError(f"Session {session_id} must contain a non-empty events list.")

    normalized_events = [
        normalize_contract_event(event, idx)
        for idx, event in enumerate(events[:MAX_EVENTS])
    ]

    label_raw = str(record.get("label", "unknown")).strip().lower() or "unknown"
    if label_raw not in LABEL_MAP:
        raise ValueError(
            f"Session {session_id} has unsupported label '{label_raw}'. "
            f"Use one of: {', '.join(sorted(LABEL_MAP))}."
        )

    return {
        "session_id": session_id,
        "label": label_raw,
        "attack_type": str(record.get("attack_type", "unspecified")).strip() or "unspecified",
        "events": normalized_events,
        "original_event_count": len(events),
    }


def validate_session_contract(path: str | Path) -> ValidationResult:
    file_path = Path(path)
    errors: list[str] = []
    warnings: list[str] = []

    try:
        records = _load_records(file_path)
    except Exception as exc:
        return ValidationResult(file_path, 0, [str(exc)], [])

    for idx, record in enumerate(records, start=1):
        try:
            normalized = normalize_contract_session(record)
            if normalized["original_event_count"] > MAX_EVENTS:
                warnings.append(
                    f"Session {normalized['session_id']} has {normalized['original_event_count']} events; "
                    f"the current prototype uses the first {MAX_EVENTS}."
                )
        except Exception as exc:
            errors.append(f"Record {idx}: {exc}")

    return ValidationResult(file_path, len(records), errors, warnings)


def format_validation_result(result: ValidationResult) -> str:
    lines = [
        f"Validated {result.session_count} session record(s) from {result.path}.",
        "Status: valid." if result.is_valid else "Status: invalid.",
    ]

    if result.warnings:
        lines.append("Warnings:")
        lines.extend(f"- {warning}" for warning in result.warnings)

    if result.errors:
        lines.append("Errors:")
        lines.extend(f"- {error}" for error in result.errors)

    if result.is_valid and not result.warnings:
        lines.append("No warnings or errors found.")

    return "\n".join(lines)


def _resource_from_record(record: dict[str, Any]) -> str:
    if record.get("resource"):
        return str(record["resource"]).strip()

    resources = record.get("resources")
    if isinstance(resources, list) and resources:
        first = resources[0]
        if isinstance(first, dict):
            return str(first.get("ARN") or first.get("arn") or first.get("resource") or "unknown").strip()
        return str(first).strip()

    return "unknown"


def _bucket_ip(value: Any) -> str:
    raw = str(value).strip()
    if not raw:
        return "ip:unknown"

    lowered = raw.lower()
    if lowered.startswith("ip:"):
        return raw
    if lowered in {"corp", "vpn", "external", "tor", "unknown"}:
        return f"ip:{lowered}"

    try:
        ip_obj = ipaddress.ip_address(raw)
        corp_networks = (
            ipaddress.ip_network("10.0.0.0/8"),
            ipaddress.ip_network("172.16.0.0/12"),
            ipaddress.ip_network("192.168.0.0/16"),
            ipaddress.ip_network("127.0.0.0/8"),
        )
        if any(ip_obj in network for network in corp_networks):
            return "ip:corp"
        return "ip:external"
    except ValueError:
        if "tor" in lowered:
            return "ip:tor"
        return "ip:external"


def _bucket_user_agent(value: Any) -> str:
    raw = str(value).strip()
    if not raw:
        return "ua:unknown"

    lowered = raw.lower()
    if lowered.startswith("ua:"):
        return raw
    if lowered in {"awscli", "console", "sdk", "unknown"}:
        return f"ua:{lowered}"
    if "aws-cli" in lowered:
        return "ua:awscli"
    if "console" in lowered or "mozilla" in lowered:
        return "ua:console"
    if "sdk" in lowered or "botocore" in lowered or "boto" in lowered or "java/" in lowered:
        return "ua:sdk"
    return "ua:unknown"


def _action_from_record(record: dict[str, Any]) -> str:
    if record.get("action"):
        return str(record["action"]).strip()

    event_name = str(record.get("eventName", "")).strip()
    event_source = str(record.get("eventSource", "")).strip()
    if not event_name or not event_source:
        raise ValueError("CloudTrail-like record must contain action or both eventName and eventSource.")

    namespace = event_source.split(".")[0]
    namespace_aliases = {"monitoring": "cloudwatch"}
    namespace = namespace_aliases.get(namespace, namespace)
    return f"{namespace}:{event_name}"


def _time_sort_key(record: dict[str, Any], fallback_index: int) -> tuple[int, str]:
    event_index = record.get("event_index")
    if isinstance(event_index, int):
        return (event_index, "")
    event_time = str(record.get("eventTime", "")).strip()
    return (fallback_index, event_time)


def _normalize_cloudtrail_like_event(record: dict[str, Any], event_index: int) -> dict[str, Any]:
    user_identity = record.get("userIdentity")
    if not isinstance(user_identity, dict):
        user_identity = {}

    return {
        "observed": bool(record.get("observed", True)),
        "action": _action_from_record(record),
        "source": f"src:{str(record.get('eventSource', 'unknown.amazonaws.com')).strip()}",
        "principal_type": f"ptype:{str(user_identity.get('type', 'Unknown')).strip()}",
        "principal_arn": f"parn:{str(user_identity.get('arn', 'unknown')).strip()}",
        "ip": _bucket_ip(record.get("sourceIPAddress") or record.get("ip_bucket")),
        "region": _ensure_prefixed(record.get("awsRegion"), "region:", "unknown"),
        "ua": _bucket_user_agent(record.get("userAgent") or record.get("ua_bucket")),
        "resource": _ensure_prefixed(_resource_from_record(record), "res:", "unknown"),
        "time_bin": _normalize_time_bin(record.get("time_bin"), event_index),
    }


def convert_cloudtrail_like_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[str, list[dict[str, Any]]] = defaultdict(list)

    for input_index, record in enumerate(records):
        session_id = str(record.get("session_id", "")).strip()
        if not session_id:
            raise ValueError("Each CloudTrail-like record must contain session_id.")
        enriched = dict(record)
        enriched["_input_index"] = input_index
        grouped[session_id].append(enriched)

    output_sessions: list[dict[str, Any]] = []
    for session_id in sorted(grouped):
        session_records = sorted(
            grouped[session_id],
            key=lambda item: _time_sort_key(item, int(item["_input_index"])),
        )
        events = [
            _normalize_cloudtrail_like_event(record, idx)
            for idx, record in enumerate(session_records[:MAX_EVENTS])
        ]

        first = session_records[0]
        label = str(first.get("label", "unknown")).strip().lower() or "unknown"
        attack_type = str(first.get("attack_type", "unspecified")).strip() or "unspecified"

        output_sessions.append(
            {
                "session_id": session_id,
                "label": label,
                "attack_type": attack_type,
                "events": events,
            }
        )

    return output_sessions


def convert_cloudtrail_jsonl_file(input_path: str | Path, output_path: str | Path) -> Path:
    records = _load_records(input_path)
    sessions = convert_cloudtrail_like_records(records)
    return _dump_jsonl(sessions, output_path)
