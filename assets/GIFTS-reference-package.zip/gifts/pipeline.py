import os
import json

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm.auto import tqdm

from .config import (
    BATCH_SIZE,
    DECODER_BETA_FIELDS,
    DECODER_LAMBDA_GEOM,
    DIFF_T,
    EMB_DIM,
    EPOCHS_DEC,
    EPOCHS_DIFF,
    EPOCHS_MLM,
    HEAL_START_T,
    INPAINT_DROP_P,
    KNOWN_LOSS_WEIGHT,
    LATENT_DIM,
    LR,
    MAX_EVENTS,
    TOKENS_PER_EVENT,
    TRUST_GEO_W,
    TRUST_HEAL_W,
    USE_MULTIFIELD_DECODER,
    get_device,
    set_seed,
)
from .data import build_dataset, session_to_actions, session_to_tokens
from .models import (
    ActionDecoder,
    SeqDiffusion,
    TokenEncoder,
    linear_beta_schedule,
    mask_inputs,
    pool_event_embeddings,
    q_sample,
)

try:
    from sklearn.manifold import Isomap

    HAVE_ISOMAP = True
except Exception:
    HAVE_ISOMAP = False

try:
    from sklearn.metrics import average_precision_score, roc_auc_score, roc_curve

    HAVE_SK_METRICS = True
except Exception:
    HAVE_SK_METRICS = False

try:
    from sklearn.ensemble import IsolationForest

    HAVE_IFOREST = True
except Exception:
    HAVE_IFOREST = False


SUSPICIOUS_ACTIONS = {
    "cloudtrail:StopLogging",
    "iam:PutRolePolicy",
    "iam:CreateAccessKey",
    "iam:AttachUserPolicy",
    "iam:CreateUser",
    "kms:Decrypt",
    "ec2:RunInstances",
    "ec2:CreateTags",
}


FIELD_NAMES = ["principal_type", "principal_arn", "source", "ip", "region", "ua", "resource"]


def build_field_vocabs(sessions):
    field_vocabs = {name: {"<PAD>": 0} for name in FIELD_NAMES}
    for sess in sessions:
        for ev in sess["full_events"]:
            for name in FIELD_NAMES:
                val = getattr(ev, name)
                if val not in field_vocabs[name]:
                    field_vocabs[name][val] = len(field_vocabs[name])
    return field_vocabs


def build_field_targets(sessions, field_vocabs):
    targets = {name: [] for name in FIELD_NAMES}
    for sess in sessions:
        for name in FIELD_NAMES:
            seq = []
            for i in range(MAX_EVENTS):
                if i < len(sess["full_events"]):
                    seq.append(field_vocabs[name].get(getattr(sess["full_events"][i], name), 0))
                else:
                    seq.append(0)
            targets[name].append(seq)
    return {name: torch.tensor(vals, dtype=torch.long) for name, vals in targets.items()}


def masked_geom_loss(zseq, hidden, valid_mask, proj):
    # Preserve relative event geometry between latent states and decoder hidden states.
    h_proj = proj(hidden)
    dist_z = torch.cdist(zseq, zseq, p=2)
    dist_h = torch.cdist(h_proj, h_proj, p=2)
    pair_mask = (valid_mask[:, :, None] * valid_mask[:, None, :]).float()
    diff = (dist_z - dist_h) ** 2
    return (diff * pair_mask).sum() / (pair_mask.sum() + 1e-6)


def _to_builtin(value):
    if isinstance(value, dict):
        return {str(k): _to_builtin(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_to_builtin(v) for v in value]
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def run_pipeline(
    report_path: str = "GIFTS_Forensic_Report_Inpaint.md",
    summary_path: str | None = None,
):
    device = get_device()
    print("Running on:", device)
    set_seed()
    effective_heal_start_t = int(max(1, min(int(HEAL_START_T), DIFF_T - 1)))

    ds = build_dataset(batch_size=BATCH_SIZE)
    print(
        f"Train={len(ds.train_data)} Test={len(ds.test_data)} | "
        f"vocab={len(ds.vocab)} | actions={len(ds.action_vocab)}"
    )
    print(
        f"Config: MLM={EPOCHS_MLM} DIFF={EPOCHS_DIFF} DEC={EPOCHS_DEC} "
        f"DIFF_T={DIFF_T} BATCH={BATCH_SIZE}"
    )

    embedder = TokenEncoder(len(ds.vocab), EMB_DIM, ds.x_obs.shape[1]).to(device)
    opt_mlm = optim.Adam(embedder.parameters(), lr=LR)
    ce_mlm = nn.CrossEntropyLoss(ignore_index=ds.pad_id)

    print("\n[Phase 1] MLM training on NORMAL observed logs (learn 'authorized language')...")
    for ep in range(EPOCHS_MLM):
        embedder.train()
        total_loss, count = 0.0, 0
        for x_obs, _, _, lb in ds.train_loader:
            normal = lb == 0
            if normal.sum() == 0:
                continue
            x = x_obs[normal].to(device)

            x_masked, mask = mask_inputs(x, pad_id=ds.pad_id, mask_id=ds.mask_id)
            logits, _ = embedder(x_masked)

            target = x.clone()
            target[~mask] = ds.pad_id
            loss = ce_mlm(logits.reshape(-1, len(ds.vocab)), target.reshape(-1))

            opt_mlm.zero_grad()
            loss.backward()
            opt_mlm.step()

            total_loss += float(loss.item())
            count += 1
        print(f"Epoch {ep + 1}/{EPOCHS_MLM} MLM loss: {total_loss / max(count, 1):.4f}")

    if not HAVE_ISOMAP:
        raise RuntimeError("scikit-learn not found for Isomap. Install scikit-learn or swap to PCA.")

    print("\n[Phase 2] Fitting Isomap on NORMAL event embeddings...")

    embedder.eval()
    normal_event_vecs = []
    with torch.no_grad():
        for x_obs, _, _, lb in ds.train_loader:
            x = x_obs[lb == 0].to(device)
            if len(x) == 0:
                continue

            _, hidden = embedder(x)
            ev = pool_event_embeddings(hidden, MAX_EVENTS, TOKENS_PER_EVENT, EMB_DIM)

            x_ev = x.view(len(x), MAX_EVENTS, TOKENS_PER_EVENT)
            is_pad_ev = (x_ev == ds.pad_id).all(dim=2)

            for b in range(ev.shape[0]):
                for i in range(MAX_EVENTS):
                    if not is_pad_ev[b, i]:
                        normal_event_vecs.append(ev[b, i].cpu().numpy())

    normal_event_vecs = np.stack(normal_event_vecs, axis=0)
    iso = Isomap(n_neighbors=15, n_components=LATENT_DIM)
    iso.fit(normal_event_vecs)
    normal_event_latent_ref = np.asarray(iso.embedding_, dtype=np.float32)

    def to_latent_seq(x_tokens: torch.Tensor):
        embedder.eval()
        with torch.no_grad():
            _, hidden = embedder(x_tokens.to(device))
            ev = pool_event_embeddings(hidden, MAX_EVENTS, TOKENS_PER_EVENT, EMB_DIM)

        batch_size = ev.shape[0]
        x_ev = x_tokens.view(batch_size, MAX_EVENTS, TOKENS_PER_EVENT)
        is_pad_ev = (x_ev == ds.pad_id).all(dim=2)

        z_out = np.zeros((batch_size, MAX_EVENTS, LATENT_DIM), dtype=np.float32)
        for b in range(batch_size):
            for i in range(MAX_EVENTS):
                if is_pad_ev[b, i]:
                    z_out[b, i] = 0.0
                else:
                    z_out[b, i] = iso.transform(ev[b, i].cpu().numpy()[None, :])[0]
        return z_out

    betas = linear_beta_schedule(DIFF_T).to(device)
    alphas = 1.0 - betas
    alpha_bar = torch.cumprod(alphas, dim=0)

    diffnet = SeqDiffusion(LATENT_DIM, MAX_EVENTS, DIFF_T).to(device)
    opt_diff = optim.Adam(diffnet.parameters(), lr=2e-3)
    mse = nn.MSELoss(reduction="none")

    print("\n[Phase 3] Train diffusion on NORMAL latent trajectories (with blackout-style masks)...")

    z_train_normal = []
    mask_train = []
    with torch.no_grad():
        for _, x_full, _, lb in ds.train_loader:
            normal = lb == 0
            if normal.sum() == 0:
                continue
            x = x_full[normal]
            z = to_latent_seq(x)
            z_train_normal.append(torch.tensor(z, dtype=torch.float32))
            x_ev = x.view(len(x), MAX_EVENTS, TOKENS_PER_EVENT)
            is_pad_ev = (x_ev == ds.pad_id).all(dim=2)
            known = (~is_pad_ev).float()
            mask_train.append(known)

    z_train_normal = torch.cat(z_train_normal, dim=0)
    mask_train = torch.cat(mask_train, dim=0)

    latent_loader = torch.utils.data.DataLoader(
        torch.utils.data.TensorDataset(z_train_normal, mask_train),
        batch_size=BATCH_SIZE,
        shuffle=True,
    )

    for _ in tqdm(range(EPOCHS_DIFF)):
        diffnet.train()
        for z0, known in latent_loader:
            z0 = z0.to(device)
            known = known.to(device)

            batch_size = z0.size(0)
            t = torch.randint(0, DIFF_T, (batch_size,), device=device)

            eps = torch.randn_like(z0)
            zt = q_sample(z0, t, eps, alpha_bar)

            drop = (torch.rand_like(known) < INPAINT_DROP_P).float() * known
            known_inpaint = (known * (1.0 - drop)).clamp(0, 1)

            unknown = 1.0 - known_inpaint
            no_unknown = unknown.sum(dim=1) == 0
            if no_unknown.any():
                idx = torch.randint(0, MAX_EVENTS, (int(no_unknown.sum()),), device=device)
                rows = torch.nonzero(no_unknown).squeeze(1)
                known_inpaint[rows, idx] = 0.0
                unknown = 1.0 - known_inpaint

            eps_pred = diffnet(zt, t, known_inpaint)

            loss_per = mse(eps_pred, eps).mean(dim=2)
            weights = unknown + KNOWN_LOSS_WEIGHT * known_inpaint
            loss = (loss_per * weights).sum() / (weights.sum() + 1e-6)

            opt_diff.zero_grad()
            loss.backward()
            opt_diff.step()

    field_vocabs = build_field_vocabs(ds.sessions)
    field_targets = build_field_targets(ds.sessions, field_vocabs)
    field_vocab_sizes = {name: len(vocab) for name, vocab in field_vocabs.items()}

    decoder = ActionDecoder(
        LATENT_DIM,
        len(ds.action_vocab),
        MAX_EVENTS,
        field_vocab_sizes=field_vocab_sizes if USE_MULTIFIELD_DECODER else None,
    ).to(device)
    opt_dec = optim.Adam(decoder.parameters(), lr=LR)
    ce = nn.CrossEntropyLoss(ignore_index=0)
    ce_fields = {name: nn.CrossEntropyLoss(ignore_index=0) for name in FIELD_NAMES}

    n_train = len(ds.train_data)
    print("[Phase 4] Precomputing latent sequences for decoder training...")
    z_train_full = torch.tensor(to_latent_seq(ds.x_full[:n_train]), dtype=torch.float32)

    if USE_MULTIFIELD_DECODER:
        decoder_train_ds = torch.utils.data.TensorDataset(
            z_train_full,
            ds.y_actions[:n_train],
            field_targets["principal_type"][:n_train],
            field_targets["principal_arn"][:n_train],
            field_targets["source"][:n_train],
            field_targets["ip"][:n_train],
            field_targets["region"][:n_train],
            field_targets["ua"][:n_train],
            field_targets["resource"][:n_train],
        )
    else:
        decoder_train_ds = torch.utils.data.TensorDataset(z_train_full, ds.y_actions[:n_train])
    decoder_train_loader = torch.utils.data.DataLoader(decoder_train_ds, batch_size=BATCH_SIZE, shuffle=True)

    print("\n[Phase 4] Train action decoder on FULL sequences (normal+attack labels unused)...")
    for ep in range(EPOCHS_DEC):
        decoder.train()
        total_loss, total_ce, total_geom, total_fields, count = 0.0, 0.0, 0.0, 0.0, 0
        for batch in decoder_train_loader:
            z_batch = batch[0]
            y_act = batch[1]
            z = z_batch.to(device)
            y = y_act.to(device)
            action_logits, field_logits, hidden = decoder(z, return_hidden=True)

            loss_ce = ce(action_logits.reshape(-1, len(ds.action_vocab)), y.reshape(-1))

            valid_mask = (y != 0).float()
            loss_geom = masked_geom_loss(z, hidden, valid_mask, decoder.geom_proj)

            if field_logits is not None:
                y_fields = {
                    "principal_type": batch[2].to(device),
                    "principal_arn": batch[3].to(device),
                    "source": batch[4].to(device),
                    "ip": batch[5].to(device),
                    "region": batch[6].to(device),
                    "ua": batch[7].to(device),
                    "resource": batch[8].to(device),
                }
                field_losses = []
                for name in FIELD_NAMES:
                    logits_f = field_logits[name]
                    target_f = y_fields[name]
                    field_losses.append(ce_fields[name](logits_f.reshape(-1, logits_f.shape[-1]), target_f.reshape(-1)))
                loss_fields = torch.stack(field_losses).mean()
            else:
                loss_fields = torch.tensor(0.0, device=device)

            loss = loss_ce + DECODER_LAMBDA_GEOM * loss_geom + DECODER_BETA_FIELDS * loss_fields

            opt_dec.zero_grad()
            loss.backward()
            opt_dec.step()

            total_loss += float(loss.item())
            total_ce += float(loss_ce.item())
            total_geom += float(loss_geom.item())
            total_fields += float(loss_fields.item())
            count += 1
        print(
            f"Epoch {ep + 1}/{EPOCHS_DEC} decoder total={total_loss / max(count, 1):.4f} "
            f"(CE={total_ce / max(count, 1):.4f}, "
            f"geom={total_geom / max(count, 1):.4f}, "
            f"fields={total_fields / max(count, 1):.4f})"
        )

    def decode_actions_from_z(zseq, topk=3):
        decoder.eval()
        with torch.no_grad():
            zt = torch.tensor(zseq, dtype=torch.float32).to(device)
            out = decoder(zt)
            action_logits = out[0] if isinstance(out, tuple) else out
            probs = torch.softmax(action_logits[0], dim=-1)

        pred = probs.argmax(dim=-1).cpu().numpy().tolist()
        pred_actions = [ds.inv_action_vocab[i] for i in pred]

        topk_info = []
        for i in range(MAX_EVENTS):
            vals, idx = torch.topk(probs[i], k=min(topk, probs.shape[-1]))
            topk_info.append([(ds.inv_action_vocab[int(j)], float(v)) for v, j in zip(vals.cpu(), idx.cpu())])
        return pred_actions, topk_info

    @torch.no_grad()
    def p_sample_step(zt, t, known_mask):
        batch_size = zt.size(0)
        t_batch = torch.full((batch_size,), t, device=device, dtype=torch.long)

        eps_pred = diffnet(zt, t_batch, known_mask)

        beta_t = betas[t]
        alpha_t = alphas[t]
        abar_t = alpha_bar[t]

        coef1 = 1 / torch.sqrt(alpha_t)
        coef2 = (1 - alpha_t) / torch.sqrt(1 - abar_t)
        mean = coef1 * (zt - coef2 * eps_pred)

        if t == 0:
            return mean

        noise = torch.randn_like(zt)
        sigma = torch.sqrt(beta_t)
        return mean + sigma * noise

    @torch.no_grad()
    def conditional_inpaint(z0_known, known_mask, num_steps=DIFF_T):
        batch_size, max_events, latent_dim = z0_known.shape

        eps_known = torch.randn((batch_size, max_events, latent_dim), device=device)

        tT = num_steps - 1
        zT = torch.randn((batch_size, max_events, latent_dim), device=device)

        abar = alpha_bar[tT].view(1, 1, 1)
        zT_known = torch.sqrt(abar) * z0_known + torch.sqrt(1 - abar) * eps_known
        zT = zT * (1 - known_mask[..., None]) + zT_known * (known_mask[..., None])

        z = zT
        for t in reversed(range(num_steps)):
            z = p_sample_step(z, t, known_mask)

            if t > 0:
                abar_prev = alpha_bar[t - 1].view(1, 1, 1)
                z_known_prev = torch.sqrt(abar_prev) * z0_known + torch.sqrt(1 - abar_prev) * eps_known
                z = z * (1 - known_mask[..., None]) + z_known_prev * (known_mask[..., None])

        return z.detach().cpu().numpy()

    def build_known_mask_from_session(sess):
        known = np.ones((MAX_EVENTS,), dtype=np.float32)
        for i in range(MAX_EVENTS):
            if i < len(sess["events"]) and sess["events"][i].action == "<BLACKOUT>":
                known[i] = 0.0
        return known

    def observed_tokens_with_blackout_masked(sess):
        toks = session_to_tokens(sess["events"])
        ids = ds.encode_tokens(toks)

        for i in range(MAX_EVENTS):
            if i < len(sess["events"]) and sess["events"][i].action == "<BLACKOUT>":
                start = i * TOKENS_PER_EVENT
                for k in range(TOKENS_PER_EVENT):
                    ids[start + k] = ds.mask_id

        return torch.tensor([ids], dtype=torch.long)

    def full_actions(sess):
        return session_to_actions(sess["full_events"])

    def obs_actions(sess):
        actions = []
        for i in range(MAX_EVENTS):
            if i < len(sess["events"]):
                actions.append(sess["events"][i].action)
            else:
                actions.append("<PAD>")
        return actions

    def candidate_plausibility(topk, blk_i, blk_j):
        if blk_i == -1:
            return 0.0
        score = 0.0
        for k in range(blk_i, blk_j):
            score += float(topk[k][0][1])
        return score / max(1, (blk_j - blk_i))

    def candidate_suspiciousness(pred, blk_i, blk_j):
        if blk_i == -1:
            return 0.0
        score = 0.0
        for k in range(blk_i, blk_j):
            action = pred[k]
            if action in SUSPICIOUS_ACTIONS:
                score += 1.0
            if "Put" in action or "Attach" in action or "Create" in action:
                score += 0.25
        return score

    def consensus_from_candidates(candidates, blk_i, blk_j):
        base_pred = list(candidates[0][0])
        vote_table = {}
        uncertainty = {}

        if blk_i == -1:
            return base_pred, uncertainty, vote_table

        for k in range(blk_i, blk_j):
            scores = {}
            for _, topk, _ in candidates:
                for action, prob in topk[k]:
                    scores[action] = scores.get(action, 0.0) + float(prob)

            ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
            vote_table[k] = ranked

            best_action, best_score = ranked[0]
            total = sum(s for _, s in ranked) + 1e-9
            confidence = best_score / total
            uncertainty[k] = float(1.0 - confidence)

            base_pred[k] = best_action

        return base_pred, uncertainty, vote_table

    def reconstruct_blackout(sess, n_samples=7):
        xb = observed_tokens_with_blackout_masked(sess)
        z_obs = to_latent_seq(xb)[0:1]

        known_mask = build_known_mask_from_session(sess)[None, :]
        z0_known = torch.tensor(z_obs, dtype=torch.float32).to(device)
        known_mask_t = torch.tensor(known_mask, dtype=torch.float32).to(device)

        candidates = []
        for _ in range(n_samples):
            z_hat = conditional_inpaint(z0_known, known_mask_t, num_steps=DIFF_T)
            pred, topk = decode_actions_from_z(z_hat, topk=3)
            candidates.append((pred, topk, z_hat))

        blk_i, blk_j = sess["blackout"]
        if blk_i == -1:
            return {
                "candidates": candidates,
                "most_plausible": candidates[0],
                "most_suspicious": candidates[0],
                "consensus_pred": candidates[0][0],
                "uncertainty": {},
                "vote_table": {},
            }

        most_plausible = max(candidates, key=lambda c: candidate_plausibility(c[1], blk_i, blk_j))
        most_suspicious = max(candidates, key=lambda c: candidate_suspiciousness(c[0], blk_i, blk_j))

        consensus_pred, uncertainty, vote_table = consensus_from_candidates(candidates, blk_i, blk_j)

        return {
            "candidates": candidates,
            "most_plausible": most_plausible,
            "most_suspicious": most_suspicious,
            "consensus_pred": consensus_pred,
            "uncertainty": uncertainty,
            "vote_table": vote_table,
        }

    def session_tokens_for_scoring(sess):
        if sess["blackout"][0] != -1:
            return observed_tokens_with_blackout_masked(sess)
        toks = session_to_tokens(sess["events"])
        return torch.tensor([ds.encode_tokens(toks)], dtype=torch.long)

    def event_masks_for_session(sess):
        visible_mask = np.zeros((MAX_EVENTS,), dtype=np.float32)
        pad_mask = np.ones((MAX_EVENTS,), dtype=np.float32)

        for i in range(MAX_EVENTS):
            if i < len(sess["events"]):
                pad_mask[i] = 0.0
                if sess["events"][i].action != "<BLACKOUT>":
                    visible_mask[i] = 1.0
        return visible_mask, pad_mask

    def geodesic_trust_score(z_seq, visible_mask):
        idx = np.where(visible_mask > 0.5)[0]
        if len(idx) == 0:
            return 0.0

        z_vis = z_seq[idx]
        d2 = ((z_vis[:, None, :] - normal_event_latent_ref[None, :, :]) ** 2).sum(axis=2)
        nearest = np.sqrt(d2.min(axis=1) + 1e-12)
        return float(nearest.mean())

    @torch.no_grad()
    def manifold_heal_projection(z_obs, pad_mask, start_t=HEAL_START_T):
        start_t = int(max(1, min(int(start_t), DIFF_T - 1)))

        z0 = torch.tensor(z_obs[None, :, :], dtype=torch.float32, device=device)
        known_mask = torch.tensor(pad_mask[None, :], dtype=torch.float32, device=device)

        eps = torch.randn_like(z0)
        t_batch = torch.full((1,), start_t, device=device, dtype=torch.long)
        z = q_sample(z0, t_batch, eps, alpha_bar)

        abar_t = alpha_bar[start_t].view(1, 1, 1)
        z_known_t = torch.sqrt(abar_t) * z0 + torch.sqrt(1 - abar_t) * eps
        z = z * (1 - known_mask[..., None]) + z_known_t * (known_mask[..., None])

        for t in reversed(range(start_t + 1)):
            z = p_sample_step(z, t, known_mask)
            if t > 0:
                abar_prev = alpha_bar[t - 1].view(1, 1, 1)
                z_known_prev = torch.sqrt(abar_prev) * z0 + torch.sqrt(1 - abar_prev) * eps
                z = z * (1 - known_mask[..., None]) + z_known_prev * (known_mask[..., None])

        return z[0].detach().cpu().numpy()

    def healing_distance_score(z_obs, z_healed, visible_mask):
        idx = np.where(visible_mask > 0.5)[0]
        if len(idx) == 0:
            return 0.0
        delta = z_obs[idx] - z_healed[idx]
        return float(np.linalg.norm(delta, axis=1).mean())

    def trust_metrics_from_scores(y_true, scores, attack_types, split_name="test", tag="default", verbose=True):
        if not HAVE_SK_METRICS:
            print(f"[Trust Eval:{split_name}] sklearn metrics unavailable; skipping.")
            return None

        y_true = np.array(y_true, dtype=np.int64)
        scores = np.array(scores, dtype=np.float64)

        if len(np.unique(y_true)) < 2:
            print(f"[Trust Eval:{split_name}] Need both classes for ROC/PR metrics; found one class only.")
            return None

        roc_auc = float(roc_auc_score(y_true, scores))
        pr_auc = float(average_precision_score(y_true, scores))

        fpr, tpr, thresholds = roc_curve(y_true, scores)
        idx = np.where(tpr >= 0.95)[0]
        if len(idx) > 0:
            k = int(idx[0])
            fpr_at_95 = float(fpr[k])
            thr_at_95 = float(thresholds[k])
        else:
            fpr_at_95 = 1.0
            thr_at_95 = float(scores.max() + 1e-6)

        pred_attack = (scores >= thr_at_95).astype(np.int64)
        tp = int(((pred_attack == 1) & (y_true == 1)).sum())
        fn = int(((pred_attack == 0) & (y_true == 1)).sum())
        fp = int(((pred_attack == 1) & (y_true == 0)).sum())
        tn = int(((pred_attack == 0) & (y_true == 0)).sum())

        per_attack = {}
        uniq_attacks = sorted({a for a, y in zip(attack_types, y_true) if y == 1})
        for attack in uniq_attacks:
            idx_a = np.array([(t == attack and y == 1) for t, y in zip(attack_types, y_true)])
            n_a = int(idx_a.sum())
            if n_a == 0:
                continue
            hit_a = int(((pred_attack == 1) & idx_a).sum())
            rec_a = hit_a / n_a
            per_attack[attack] = {"recall": rec_a, "hit": hit_a, "total": n_a}

        if verbose:
            print(f"\n[Trust Eval:{split_name}:{tag}]")
            print(f"ROC-AUC={roc_auc:.4f} | PR-AUC={pr_auc:.4f} | FPR@TPR=0.95={fpr_at_95:.4f}")
            print(f"Threshold@TPR=0.95={thr_at_95:.6f}")
            print(f"Confusion at threshold: TP={tp} FN={fn} FP={fp} TN={tn}")
            if len(per_attack) > 0:
                print("Per-attack recall at threshold:")
                for attack in sorted(per_attack.keys()):
                    info = per_attack[attack]
                    print(f" - {attack}: recall={info['recall']:.4f} ({info['hit']}/{info['total']})")

        return {
            "roc_auc": roc_auc,
            "pr_auc": pr_auc,
            "fpr_at_tpr95": fpr_at_95,
            "threshold_tpr95": thr_at_95,
            "tp": tp,
            "fn": fn,
            "fp": fp,
            "tn": tn,
            "per_attack": per_attack,
        }

    def build_trust_cache(sessions_eval, split_name="test"):
        cache = []
        for sess in tqdm(sessions_eval, desc=f"[Trust Cache:{split_name}]"):
            xb = session_tokens_for_scoring(sess)
            z_obs = to_latent_seq(xb)[0]
            visible_mask, pad_mask = event_masks_for_session(sess)
            s_geo = geodesic_trust_score(z_obs, visible_mask)
            cache.append(
                {
                    "z_obs": z_obs,
                    "visible_mask": visible_mask,
                    "pad_mask": pad_mask,
                    "label": int(sess["label"]),
                    "attack_type": sess["attack_type"],
                    "s_geo": float(s_geo),
                }
            )
        return cache

    def compute_s_heal(cache, start_t, split_name="test"):
        s_heal = []
        for item in tqdm(cache, desc=f"[Trust Heal:{split_name}:t={start_t}]"):
            z_healed = manifold_heal_projection(item["z_obs"], item["pad_mask"], start_t=start_t)
            s_heal.append(healing_distance_score(item["z_obs"], z_healed, item["visible_mask"]))
        return np.array(s_heal, dtype=np.float64)

    def evaluate_trust_detector(sessions_eval, split_name="test"):
        if not HAVE_SK_METRICS:
            print(f"[Trust Eval:{split_name}] sklearn metrics unavailable; skipping.")
            return None

        cache = build_trust_cache(sessions_eval, split_name=split_name)
        y_true = np.array([c["label"] for c in cache], dtype=np.int64)
        attack_types = [c["attack_type"] for c in cache]
        s_geo = np.array([c["s_geo"] for c in cache], dtype=np.float64)
        s_heal_default = compute_s_heal(cache, start_t=effective_heal_start_t, split_name=split_name)

        scores_default = TRUST_GEO_W * s_geo + TRUST_HEAL_W * s_heal_default
        metrics_default = trust_metrics_from_scores(
            y_true,
            scores_default,
            attack_types,
            split_name=split_name,
            tag=f"default(wg={TRUST_GEO_W},wh={TRUST_HEAL_W},t={effective_heal_start_t})",
            verbose=True,
        )
        if metrics_default is None:
            return None

        print(
            f"Mean S_geo={np.mean(s_geo):.4f} | "
            f"Mean S_heal(t={effective_heal_start_t})={np.mean(s_heal_default):.4f}"
        )

        if os.getenv("GIFTS_TRUST_SWEEP", "0") != "1":
            return metrics_default

        starts_raw = os.getenv("GIFTS_TRUST_SWEEP_STARTS", "")
        if starts_raw.strip():
            start_candidates = [int(x.strip()) for x in starts_raw.split(",") if x.strip()]
        else:
            start_candidates = sorted(
                set(
                    [
                        max(1, min(DIFF_T - 1, effective_heal_start_t - 20)),
                        effective_heal_start_t,
                        max(1, min(DIFF_T - 1, effective_heal_start_t + 20)),
                    ]
                )
            )

        weights_raw = os.getenv("GIFTS_TRUST_SWEEP_WEIGHTS", "")
        if weights_raw.strip():
            weight_candidates = []
            for part in weights_raw.split(","):
                if ":" not in part:
                    continue
                wg, wh = part.split(":", 1)
                weight_candidates.append((float(wg), float(wh)))
        else:
            weight_candidates = [(1.0, 1.0), (0.7, 1.3), (1.3, 0.7), (0.5, 1.5), (1.5, 0.5)]

        print(f"\n[Trust Sweep:{split_name}] starts={start_candidates} weights={weight_candidates}")

        s_heal_by_start = {HEAL_START_T: s_heal_default}
        for t_start in start_candidates:
            if t_start not in s_heal_by_start:
                s_heal_by_start[t_start] = compute_s_heal(cache, start_t=t_start, split_name=split_name)

        best = None
        rows = []
        for t_start in start_candidates:
            s_heal_cur = s_heal_by_start[t_start]
            for wg, wh in weight_candidates:
                scores = wg * s_geo + wh * s_heal_cur
                m = trust_metrics_from_scores(
                    y_true,
                    scores,
                    attack_types,
                    split_name=split_name,
                    tag=f"sweep(wg={wg},wh={wh},t={t_start})",
                    verbose=False,
                )
                if m is None:
                    continue
                row = {
                    "start_t": t_start,
                    "wg": wg,
                    "wh": wh,
                    "fpr_at_tpr95": m["fpr_at_tpr95"],
                    "roc_auc": m["roc_auc"],
                    "pr_auc": m["pr_auc"],
                }
                rows.append(row)
                if best is None:
                    best = row
                else:
                    cur_key = (row["fpr_at_tpr95"], -row["roc_auc"], -row["pr_auc"])
                    best_key = (best["fpr_at_tpr95"], -best["roc_auc"], -best["pr_auc"])
                    if cur_key < best_key:
                        best = row

        rows = sorted(rows, key=lambda r: (r["fpr_at_tpr95"], -r["roc_auc"], -r["pr_auc"]))
        print("[Trust Sweep Results] Top settings by low-FPR:")
        for r in rows[:5]:
            print(
                f" - t={r['start_t']} wg={r['wg']:.2f} wh={r['wh']:.2f} | "
                f"FPR@95={r['fpr_at_tpr95']:.4f} ROC-AUC={r['roc_auc']:.4f} PR-AUC={r['pr_auc']:.4f}"
            )

        if best is not None:
            print(
                f"[Trust Sweep Best] t={best['start_t']} wg={best['wg']:.2f} wh={best['wh']:.2f} | "
                f"FPR@95={best['fpr_at_tpr95']:.4f} ROC-AUC={best['roc_auc']:.4f} PR-AUC={best['pr_auc']:.4f}"
            )
            metrics_default["sweep_best"] = best
            metrics_default["sweep_top5"] = rows[:5]

        return metrics_default

    def session_feature_vector(z_seq, visible_mask):
        idx = np.where(visible_mask > 0.5)[0]
        if len(idx) == 0:
            return np.zeros((LATENT_DIM,), dtype=np.float32)
        return np.asarray(z_seq[idx].mean(axis=0), dtype=np.float32)

    def evaluate_isolation_forest_baseline(train_sessions, eval_sessions, split_name="test"):
        if not HAVE_IFOREST:
            print(f"[IF Baseline:{split_name}] sklearn IsolationForest unavailable; skipping.")
            return None

        x_train = []
        for sess in tqdm(train_sessions, desc="[IF Baseline:train-features]"):
            if int(sess["label"]) != 0:
                continue
            xb = session_tokens_for_scoring(sess)
            z_obs = to_latent_seq(xb)[0]
            visible_mask, _ = event_masks_for_session(sess)
            x_train.append(session_feature_vector(z_obs, visible_mask))

        if len(x_train) < 10:
            print(f"[IF Baseline:{split_name}] Not enough normal training sessions; skipping.")
            return None

        clf = IsolationForest(
            n_estimators=200,
            contamination="auto",
            random_state=42,
        )
        clf.fit(np.asarray(x_train, dtype=np.float32))

        x_eval, y_true, attack_types = [], [], []
        for sess in tqdm(eval_sessions, desc=f"[IF Baseline:{split_name}-features]"):
            xb = session_tokens_for_scoring(sess)
            z_obs = to_latent_seq(xb)[0]
            visible_mask, _ = event_masks_for_session(sess)
            x_eval.append(session_feature_vector(z_obs, visible_mask))
            y_true.append(int(sess["label"]))
            attack_types.append(sess["attack_type"])

        x_eval = np.asarray(x_eval, dtype=np.float32)
        scores = -clf.decision_function(x_eval)
        metrics = trust_metrics_from_scores(
            y_true,
            scores,
            attack_types,
            split_name=split_name,
            tag="IsolationForest-baseline",
            verbose=True,
        )
        if metrics is None:
            return None

        pred_attack = (scores >= metrics["threshold_tpr95"]).astype(np.int64)
        metrics["scores"] = scores
        metrics["pred_attack_mask"] = pred_attack
        metrics["n_flagged"] = int(pred_attack.sum())
        metrics["n_eval"] = int(len(pred_attack))
        return metrics

    def build_reconstruction_summary(sess):
        out = reconstruct_blackout(sess, n_samples=7)

        pred_plaus, _, _ = out["most_plausible"]
        pred_susp, _, _ = out["most_suspicious"]
        consensus_pred = out["consensus_pred"]
        uncertainty = out["uncertainty"]
        vote_table = out["vote_table"]
        candidates = out["candidates"]

        obs = obs_actions(sess)
        gt = full_actions(sess)
        blk_i, blk_j = sess["blackout"]

        reconstruction_summary = {
            "attack_type": sess["attack_type"],
            "label": int(sess["label"]),
            "blackout_interval": [int(blk_i), int(blk_j)],
            "hypotheses_generated": int(len(candidates)),
            "observed_actions": obs,
            "ground_truth_full_actions": gt,
            "most_plausible_actions": pred_plaus,
            "most_suspicious_actions": pred_susp,
            "consensus_actions": consensus_pred,
            "missing_indices": list(range(blk_i, blk_j)) if blk_i != -1 else [],
            "ground_truth_missing_actions": [gt[k] for k in range(blk_i, blk_j)] if blk_i != -1 else [],
            "consensus_missing_actions": [consensus_pred[k] for k in range(blk_i, blk_j)] if blk_i != -1 else [],
            "uncertainty_by_index": {str(k): float(v) for k, v in uncertainty.items()},
            "vote_table_by_index": {
                str(k): [{"action": action, "vote_score": float(score)} for action, score in ranked[:5]]
                for k, ranked in vote_table.items()
            },
            "hypothesis_summaries": [],
        }

        if blk_i != -1:
            for idx, (pred_i, topk_i, _) in enumerate(candidates, start=1):
                reconstruction_summary["hypothesis_summaries"].append(
                    {
                        "hypothesis_index": idx,
                        "plausibility_score": float(candidate_plausibility(topk_i, blk_i, blk_j)),
                        "suspiciousness_score": float(candidate_suspiciousness(pred_i, blk_i, blk_j)),
                        "missing_predictions": [pred_i[k] for k in range(blk_i, blk_j)],
                    }
                )

        return reconstruction_summary

    def forensic_report(sess, path=report_path):
        reconstruction_summary = build_reconstruction_summary(sess)
        blk_i, blk_j = reconstruction_summary["blackout_interval"]

        lines = []
        lines.append("# GIFTS Forensic Report (Conditional Inpainting Diffusion)\n")
        lines.append(
            f"- **Attack type**: `{reconstruction_summary['attack_type']}` | "
            f"label={reconstruction_summary['label']}\n"
        )
        lines.append(f"- **Blackout interval**: `{tuple(reconstruction_summary['blackout_interval'])}`\n")
        lines.append(f"- **Hypotheses generated**: `{reconstruction_summary['hypotheses_generated']}`\n")

        lines.append("\n---\n## Observed Actions\n")
        for i, action in enumerate(reconstruction_summary["observed_actions"]):
            lines.append(f"- [{i:02d}] {action}")

        lines.append("\n\n## Ground Truth Full Actions\n")
        for i, action in enumerate(reconstruction_summary["ground_truth_full_actions"]):
            lines.append(f"- [{i:02d}] {action}")

        lines.append("\n\n---\n## Reconstructed Actions (Multi-Hypothesis Inpainting)\n")
        lines.append("### Most plausible reconstruction\n")
        for i, action in enumerate(reconstruction_summary["most_plausible_actions"]):
            lines.append(f"- [{i:02d}] {action}")

        lines.append("\n\n### Most suspicious reconstruction\n")
        for i, action in enumerate(reconstruction_summary["most_suspicious_actions"]):
            lines.append(f"- [{i:02d}] {action}")

        lines.append("\n\n### Consensus reconstruction (recommended)\n")
        for i, action in enumerate(reconstruction_summary["consensus_actions"]):
            lines.append(f"- [{i:02d}] {action}")

        if blk_i != -1:
            lines.append("\n\n---\n## Blackout Segment Reconstruction\n")
            lines.append(f"Missing indices: `{reconstruction_summary['missing_indices']}`\n")

            lines.append("\n### Ground Truth Missing\n")
            for k, action in zip(reconstruction_summary["missing_indices"], reconstruction_summary["ground_truth_missing_actions"]):
                lines.append(f"- [{k:02d}] {action}")

            lines.append("\n### Consensus Missing (Recommended)\n")
            for k, action in zip(reconstruction_summary["missing_indices"], reconstruction_summary["consensus_missing_actions"]):
                lines.append(f"- [{k:02d}] {action}")

            lines.append("\n### Consensus + Uncertainty per Missing Slot\n")
            for k in range(blk_i, blk_j):
                unc = reconstruction_summary["uncertainty_by_index"].get(str(k), 0.0)
                top = reconstruction_summary["vote_table_by_index"].get(str(k), [])
                pretty = ", ".join([f"{item['action']} (vote={item['vote_score']:.2f})" for item in top])
                lines.append(
                    f"- [{k:02d}] consensus={reconstruction_summary['consensus_actions'][k]} | "
                    f"uncertainty={unc:.2f} | {pretty}"
                )

            lines.append("\n\n---\n## All hypotheses (missing-slot predictions)\n")
            for item in reconstruction_summary["hypothesis_summaries"]:
                lines.append(
                    f"- Hypothesis {item['hypothesis_index']:02d}: "
                    f"plaus={item['plausibility_score']:.2f} | "
                    f"susp={item['suspiciousness_score']:.2f} | "
                    f"missing={item['missing_predictions']}"
                )

        report = "\n".join(lines)
        with open(path, "w", encoding="utf-8") as f:
            f.write(report)

        print("\nSaved forensic report:", path)
        print("\n".join(lines[:70]))
        print("\n... (preview truncated) ...\n")
        return reconstruction_summary

    print("\n[Phase 5] Evaluate IsolationForest baseline (Fast Path)...")
    if_metrics = evaluate_isolation_forest_baseline(ds.sessions_train, ds.sessions_test, split_name="test")
    deep_on_flagged_only = os.getenv("GIFTS_DEEP_ON_FLAGGED_ONLY", "1") == "1"

    sessions_for_deep = ds.sessions_test
    if deep_on_flagged_only and if_metrics is not None:
        flag_mask = if_metrics.get("pred_attack_mask")
        if flag_mask is not None:
            flagged_idx = np.where(flag_mask == 1)[0].tolist()
            sessions_for_deep = [ds.sessions_test[i] for i in flagged_idx]
            print(
                f"[Fast->Deep Router] flagged={len(sessions_for_deep)}/{len(ds.sessions_test)} "
                f"(GIFTS_DEEP_ON_FLAGGED_ONLY=1)"
            )
            if len(sessions_for_deep) == 0:
                print("[Fast->Deep Router] No sessions flagged; skipping Deep Path scoring.")

    print("\n[Phase 6] Evaluate geodesic + healing trust detector (Deep Path)...")
    trust_metrics = None
    if len(sessions_for_deep) > 0:
        trust_metrics = evaluate_trust_detector(sessions_for_deep, split_name="deep")
        if trust_metrics is None and deep_on_flagged_only:
            print("[Deep Path] Flagged subset has a single class; falling back to full test for metrics.")
            trust_metrics = evaluate_trust_detector(ds.sessions_test, split_name="test")

    print("\n--- DEMO: Conditional Inpainting Reconstruction (Multi-Hypothesis) ---")
    target = None
    for session in sessions_for_deep:
        if session["label"] == 1 and session["blackout"][0] != -1:
            target = session
            break

    if target is None:
        for session in ds.sessions_test:
            if session["label"] == 1 and session["blackout"][0] != -1:
                target = session
                break

    if target is None:
        print("No blackout attacks found in test split. Increase blackout_prob or N_ATTACK.")
        reconstruction_summary = None
    else:
        reconstruction_summary = forensic_report(target, path=report_path)

    def compact_metrics(metrics):
        if metrics is None:
            return None
        compact = {k: v for k, v in metrics.items() if k not in {"scores", "pred_attack_mask"}}
        return _to_builtin(compact)

    run_summary = {
        "schema_version": "gifts-output-summary-v1",
        "package_role": "reference-implementation",
        "runtime": {
            "device": str(device),
            "report_path": report_path,
            "summary_path": summary_path,
        },
        "config": {
            "batch_size": BATCH_SIZE,
            "epochs_mlm": EPOCHS_MLM,
            "epochs_diff": EPOCHS_DIFF,
            "epochs_dec": EPOCHS_DEC,
            "diff_t": DIFF_T,
            "requested_heal_start_t": HEAL_START_T,
            "effective_heal_start_t": effective_heal_start_t,
            "trust_geo_w": TRUST_GEO_W,
            "trust_heal_w": TRUST_HEAL_W,
            "max_events": MAX_EVENTS,
            "tokens_per_event": TOKENS_PER_EVENT,
            "latent_dim": LATENT_DIM,
            "embedding_dim": EMB_DIM,
        },
        "dataset": {
            "train_sessions": int(len(ds.train_data)),
            "test_sessions": int(len(ds.test_data)),
            "vocab_size": int(len(ds.vocab)),
            "action_vocab_size": int(len(ds.action_vocab)),
        },
        "fast_path_metrics": compact_metrics(if_metrics),
        "deep_path_metrics": compact_metrics(trust_metrics),
        "forensic_demo": _to_builtin(reconstruction_summary),
    }

    if summary_path:
        with open(summary_path, "w", encoding="utf-8") as handle:
            json.dump(run_summary, handle, indent=2, sort_keys=True)
        print("Saved run summary:", summary_path)

    return {
        "trust_metrics": trust_metrics,
        "if_baseline_metrics": if_metrics,
        "dataset": ds,
        "embedder": embedder,
        "diffnet": diffnet,
        "decoder": decoder,
        "run_summary": run_summary,
    }
