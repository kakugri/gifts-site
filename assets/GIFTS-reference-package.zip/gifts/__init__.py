def main(*args, **kwargs):
    from .cli import main as _main

    return _main(*args, **kwargs)


def run_pipeline(*args, **kwargs):
    from .pipeline import run_pipeline as _run_pipeline

    return _run_pipeline(*args, **kwargs)


def score_session_file(*args, **kwargs):
    from .workflow import score_session_file as _score_session_file

    return _score_session_file(*args, **kwargs)


__all__ = ["main", "run_pipeline", "score_session_file"]
