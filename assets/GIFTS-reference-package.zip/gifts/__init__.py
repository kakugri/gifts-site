def main(*args, **kwargs):
    from .cli import main as _main

    return _main(*args, **kwargs)


def run_pipeline(*args, **kwargs):
    from .pipeline import run_pipeline as _run_pipeline

    return _run_pipeline(*args, **kwargs)


__all__ = ["main", "run_pipeline"]
