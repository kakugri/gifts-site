from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from .contracts import load_session_contract_records, normalize_contract_session


SENSITIVE_ACTION_WEIGHTS = {
    "cloudtrail:StopLogging": 32,
    "cloudtrail:DeleteTrail": 32,
    "iam:PutRolePolicy": 28,
    "iam:AttachUserPolicy": 26,
    "iam:CreateAccessKey": 24,
    "iam:CreateUser": 22,
    "iam:UpdateAssumeRolePolicy": 22,
    "iam:CreatePolicyVersion": 20,
    "kms:Decrypt": 18,
    "s3:GetObject": 8,
    "s3:PutObject": 6,
    "ec2:RunInstances": 18,
    "ec2:CreateTags": 8,
    "organizations:LeaveOrganization": 30,
    "organizations:AttachPolicy": 24,
}

PRIVILEGE_ACTION_FRAGMENTS = (
    "PutRolePolicy",
    "AttachUserPolicy",
    "CreateAccessKey",
    "CreateUser",
    "UpdateAssumeRolePolicy",
    "CreatePolicyVersion",
)


def _event_dict(event, index: int) -> dict[str, Any]:
    return {
        "index": index,
        "action": event.action,
        "source": event.source,
        "principal_type": event.principal_type,
        "principal_arn": event.principal_arn,
        "ip": event.ip,
        "region": event.region,
        "ua": event.ua,
        "resource": event.resource,
        "time_bin": event.time_bin,
    }


def _risk_level(score: int) -> str:
    if score >= 80:
        return "critical"
    if score >= 55:
        return "high"
    if score >= 25:
        return "medium"
    return "low"


def _add_signal(signals: list[dict[str, Any]], name: str, weight: int, description: str, evidence: list[str]) -> None:
    signals.append(
        {
            "name": name,
            "weight": int(weight),
            "description": description,
            "evidence": evidence,
        }
    )


def _recommended_actions(level: str, signals: list[dict[str, Any]]) -> list[str]:
    signal_names = {signal["name"] for signal in signals}
    actions = []

    if level in {"critical", "high"}:
        actions.append("Open an identity-security triage item for this session.")
        actions.append("Review the principal, source IP category, user agent, and target resources.")
    elif level == "medium":
        actions.append("Queue this session for analyst review or weekly identity-control review.")
    else:
        actions.append("Retain as baseline context unless correlated with another alert.")

    if "missing_or_blacked_out_events" in signal_names:
        actions.append("Check whether logging gaps, suppressed telemetry, or event-delivery delays explain the missing segment.")
    if "privilege_change_sequence" in signal_names:
        actions.append("Verify whether the privilege change was approved and revoke unexpected access changes.")
    if "external_or_tor_source" in signal_names:
        actions.append("Correlate the source network with VPN, geolocation, and known corporate egress paths.")
    if "logging_control_action" in signal_names:
        actions.append("Confirm CloudTrail or audit logging continuity for the affected account or tenant.")

    return actions


def score_session(record: dict[str, Any]) -> dict[str, Any]:
    normalized = normalize_contract_session(record)
    events = normalized["events"]
    signals: list[dict[str, Any]] = []
    suspicious_actions = []

    score = 0
    observed_events = [event for event in events if event.action != "<BLACKOUT>"]
    blackout_indices = [idx for idx, event in enumerate(events) if event.action == "<BLACKOUT>"]

    for idx, event in enumerate(events):
        if event.action == "<BLACKOUT>":
            continue
        weight = SENSITIVE_ACTION_WEIGHTS.get(event.action, 0)
        if weight:
            suspicious_actions.append(
                {
                    "index": idx,
                    "action": event.action,
                    "weight": weight,
                    "reason": "Sensitive identity, logging, data, or infrastructure action.",
                }
            )
            score += weight

    if suspicious_actions:
        top = [f"[{item['index']:02d}] {item['action']}" for item in suspicious_actions[:5]]
        _add_signal(
            signals,
            "sensitive_actions",
            min(35, sum(item["weight"] for item in suspicious_actions)),
            "Session contains actions that often deserve identity-security review.",
            top,
        )

    if blackout_indices:
        weight = min(30, 12 * len(blackout_indices))
        score += weight
        _add_signal(
            signals,
            "missing_or_blacked_out_events",
            weight,
            "Session contains intentionally missing or blacked-out event slots.",
            [f"missing_indices={blackout_indices}"],
        )

    ip_values = sorted({event.ip for event in observed_events})
    if any(ip in {"ip:external", "ip:tor"} for ip in ip_values):
        weight = 24 if "ip:tor" in ip_values else 14
        score += weight
        _add_signal(
            signals,
            "external_or_tor_source",
            weight,
            "Session includes access from an external or Tor-like source category.",
            ip_values,
        )

    unknown_uas = sorted({event.ua for event in observed_events if event.ua == "ua:unknown"})
    if unknown_uas:
        score += 8
        _add_signal(
            signals,
            "unknown_user_agent",
            8,
            "Session contains an unknown user-agent bucket.",
            unknown_uas,
        )

    principals = sorted({event.principal_arn for event in observed_events})
    suspicious_principals = [
        principal
        for principal in principals
        if any(token in principal.lower() for token in ("unknown", "stolen", "suspicious"))
    ]
    if suspicious_principals:
        score += 18
        _add_signal(
            signals,
            "suspicious_principal_label",
            18,
            "Principal naming suggests an unknown, suspicious, or stolen-token context in the example data.",
            suspicious_principals,
        )

    actions = [event.action for event in observed_events]
    if "cloudtrail:StopLogging" in actions:
        score += 20
        _add_signal(
            signals,
            "logging_control_action",
            20,
            "Session includes a logging-control action that can reduce audit visibility.",
            ["cloudtrail:StopLogging"],
        )

    if any(fragment in action for action in actions for fragment in PRIVILEGE_ACTION_FRAGMENTS):
        score += 18
        _add_signal(
            signals,
            "privilege_change_sequence",
            18,
            "Session includes privilege, access-key, or policy-change behavior.",
            [action for action in actions if any(fragment in action for fragment in PRIVILEGE_ACTION_FRAGMENTS)],
        )

    if {"ec2:RunInstances", "ec2:CreateTags"}.issubset(set(actions)):
        score += 12
        _add_signal(
            signals,
            "resource_creation_sequence",
            12,
            "Session includes resource creation followed by tagging or metadata changes.",
            ["ec2:RunInstances", "ec2:CreateTags"],
        )

    regions = sorted({event.region for event in observed_events})
    if len(regions) > 1:
        score += 6
        _add_signal(
            signals,
            "multi_region_session",
            6,
            "Session spans multiple regions.",
            regions,
        )

    score = max(0, min(100, int(score)))
    level = _risk_level(score)

    return {
        "schema_version": "gifts-workflow-finding-v1",
        "session_id": normalized["session_id"],
        "label": normalized["label"],
        "attack_type": normalized["attack_type"],
        "risk_score": score,
        "risk_level": level,
        "event_count": len(events),
        "observed_event_count": len(observed_events),
        "blackout_count": len(blackout_indices),
        "identity_context": {
            "principals": principals,
            "ip_categories": ip_values,
            "regions": regions,
            "user_agents": sorted({event.ua for event in observed_events}),
        },
        "suspicious_actions": suspicious_actions,
        "signals": sorted(signals, key=lambda item: item["weight"], reverse=True),
        "recommended_actions": _recommended_actions(level, signals),
        "events": [_event_dict(event, idx) for idx, event in enumerate(events)],
        "workflow_uses": [
            "SOC triage",
            "identity-control review",
            "incident reconstruction support",
            "red-team or tabletop evaluation",
        ],
    }


def score_session_records(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return [score_session(record) for record in records]


def write_findings_jsonl(findings: list[dict[str, Any]], output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as handle:
        for finding in findings:
            handle.write(json.dumps(finding, sort_keys=True))
            handle.write("\n")
    return path


def write_findings_csv(findings: list[dict[str, Any]], output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "session_id",
                "risk_level",
                "risk_score",
                "label",
                "attack_type",
                "event_count",
                "blackout_count",
                "suspicious_actions",
                "top_signals",
                "recommended_action",
            ],
        )
        writer.writeheader()
        for finding in findings:
            writer.writerow(
                {
                    "session_id": finding["session_id"],
                    "risk_level": finding["risk_level"],
                    "risk_score": finding["risk_score"],
                    "label": finding["label"],
                    "attack_type": finding["attack_type"],
                    "event_count": finding["event_count"],
                    "blackout_count": finding["blackout_count"],
                    "suspicious_actions": "; ".join(item["action"] for item in finding["suspicious_actions"]),
                    "top_signals": "; ".join(signal["name"] for signal in finding["signals"][:3]),
                    "recommended_action": finding["recommended_actions"][0] if finding["recommended_actions"] else "",
                }
            )
    return path


def render_workflow_report(findings: list[dict[str, Any]], source_path: str | Path) -> str:
    sorted_findings = sorted(findings, key=lambda item: item["risk_score"], reverse=True)
    counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    for finding in findings:
        counts[finding["risk_level"]] += 1

    lines = [
        "# GIFTS Workflow Findings Report",
        "",
        f"- Source file: `{source_path}`",
        f"- Sessions scored: `{len(findings)}`",
        (
            "- Risk mix: "
            f"`critical={counts['critical']}`, `high={counts['high']}`, "
            f"`medium={counts['medium']}`, `low={counts['low']}`"
        ),
        "",
        "## Triage Queue",
        "",
        "| Session | Risk | Score | Top signals | Recommended first action |",
        "| --- | --- | ---: | --- | --- |",
    ]

    for finding in sorted_findings:
        top_signals = ", ".join(signal["name"] for signal in finding["signals"][:3]) or "none"
        first_action = finding["recommended_actions"][0] if finding["recommended_actions"] else "Review if correlated."
        lines.append(
            f"| `{finding['session_id']}` | `{finding['risk_level']}` | {finding['risk_score']} | "
            f"{top_signals} | {first_action} |"
        )

    for finding in sorted_findings:
        lines.extend(
            [
                "",
                f"## Session `{finding['session_id']}`",
                "",
                f"- Risk: `{finding['risk_level']}` / `{finding['risk_score']}`",
                f"- Label: `{finding['label']}`",
                f"- Attack type: `{finding['attack_type']}`",
                f"- Events: `{finding['event_count']}` total, `{finding['blackout_count']}` missing or blacked out",
                "",
                "Signals:",
            ]
        )
        if finding["signals"]:
            for signal in finding["signals"]:
                evidence = "; ".join(signal["evidence"])
                lines.append(f"- `{signal['name']}` (+{signal['weight']}): {signal['description']} Evidence: {evidence}")
        else:
            lines.append("- No elevated workflow signals found.")

        lines.extend(["", "Recommended actions:"])
        for action in finding["recommended_actions"]:
            lines.append(f"- {action}")

    lines.extend(
        [
            "",
            "## Interpretation Guardrail",
            "",
            (
                "These findings are workflow-prioritization outputs from the public GIFTS "
                "reference package. They are intended to help analysts decide what to review, "
                "not to serve as final forensic conclusions or production detection guarantees."
            ),
        ]
    )
    return "\n".join(lines) + "\n"


def write_workflow_report(findings: list[dict[str, Any]], source_path: str | Path, output_path: str | Path) -> Path:
    path = Path(output_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(render_workflow_report(findings, source_path), encoding="utf-8")
    return path


def score_session_file(
    input_path: str | Path,
    findings_path: str | Path | None = None,
    csv_path: str | Path | None = None,
    report_path: str | Path | None = None,
) -> list[dict[str, Any]]:
    records = load_session_contract_records(input_path)
    findings = score_session_records(records)

    if findings_path:
        write_findings_jsonl(findings, findings_path)
    if csv_path:
        write_findings_csv(findings, csv_path)
    if report_path:
        write_workflow_report(findings, input_path, report_path)

    return findings


def format_score_summary(findings: list[dict[str, Any]]) -> str:
    lines = [f"Scored {len(findings)} session(s)."]
    for finding in sorted(findings, key=lambda item: item["risk_score"], reverse=True):
        top_signals = ", ".join(signal["name"] for signal in finding["signals"][:3]) or "none"
        lines.append(
            f"- {finding['session_id']}: {finding['risk_level']} "
            f"({finding['risk_score']}) | signals: {top_signals}"
        )
    return "\n".join(lines)
