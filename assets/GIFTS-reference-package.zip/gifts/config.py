import random
import os

import numpy as np
import torch

SEED = 42

MAX_EVENTS = 10
TOKENS_PER_EVENT = 9
SEQ_LEN = MAX_EVENTS * TOKENS_PER_EVENT

EMB_DIM = 64
LATENT_DIM = 3

BATCH_SIZE = 128
LR = 1e-3

EPOCHS_MLM = 4
EPOCHS_DIFF = 60
EPOCHS_DEC = 6

DIFF_T = 250

# Inpainting-aware diffusion training
INPAINT_DROP_P = 0.25
KNOWN_LOSS_WEIGHT = 0.05

# Trust scoring
HEAL_START_T = 20
TRUST_GEO_W = 1.5
TRUST_HEAL_W = 0.5

# Decoder composite objective
USE_MULTIFIELD_DECODER = True
DECODER_LAMBDA_GEOM = 0.1
DECODER_BETA_FIELDS = 0.5

SPECIALS = ["<PAD>", "<CLS>", "<MASK>", "<UNK>"]
PAD, CLS, MASK, UNK = SPECIALS

# Dataset sizes
N_NORMAL = 3200
N_ATTACK = 500


def _env_int(name: str, default: int) -> int:
    v = os.getenv(name)
    if v is None:
        return default
    try:
        return int(v)
    except ValueError:
        return default


def _env_float(name: str, default: float) -> float:
    v = os.getenv(name)
    if v is None:
        return default
    try:
        return float(v)
    except ValueError:
        return default


EPOCHS_MLM = _env_int("GIFTS_EPOCHS_MLM", EPOCHS_MLM)
EPOCHS_DIFF = _env_int("GIFTS_EPOCHS_DIFF", EPOCHS_DIFF)
EPOCHS_DEC = _env_int("GIFTS_EPOCHS_DEC", EPOCHS_DEC)
DIFF_T = _env_int("GIFTS_DIFF_T", DIFF_T)
BATCH_SIZE = _env_int("GIFTS_BATCH_SIZE", BATCH_SIZE)
N_NORMAL = _env_int("GIFTS_N_NORMAL", N_NORMAL)
N_ATTACK = _env_int("GIFTS_N_ATTACK", N_ATTACK)
HEAL_START_T = _env_int("GIFTS_HEAL_START_T", HEAL_START_T)
INPAINT_DROP_P = _env_float("GIFTS_INPAINT_DROP_P", INPAINT_DROP_P)
KNOWN_LOSS_WEIGHT = _env_float("GIFTS_KNOWN_LOSS_WEIGHT", KNOWN_LOSS_WEIGHT)
DECODER_LAMBDA_GEOM = _env_float("GIFTS_DECODER_LAMBDA_GEOM", DECODER_LAMBDA_GEOM)
DECODER_BETA_FIELDS = _env_float("GIFTS_DECODER_BETA_FIELDS", DECODER_BETA_FIELDS)


def get_device() -> torch.device:
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def set_seed(seed: int = SEED) -> None:
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
