import random
from dataclasses import dataclass
from typing import Dict, List, Tuple

import torch
from torch.utils.data import DataLoader, TensorDataset

from .config import (
    BATCH_SIZE,
    MASK,
    MAX_EVENTS,
    N_ATTACK,
    N_NORMAL,
    PAD,
    SEQ_LEN,
    SPECIALS,
    TOKENS_PER_EVENT,
    UNK,
)

REGIONS = ["us-east-1", "us-west-2"]
IP_BUCKETS = ["ip:corp", "ip:vpn", "ip:external", "ip:tor"]
UA_BUCKETS = ["ua:awscli", "ua:console", "ua:sdk", "ua:unknown"]
RESOURCE_BUCKETS = ["res:s3_A", "res:s3_B", "res:iam_role_dev", "res:kms_key_X"]

PRINCIPALS_NORMAL = [
    ("ptype:AssumedRole", "parn:arn:aws:iam::111122223333:role/dev_role"),
    ("ptype:AssumedRole", "parn:arn:aws:iam::111122223333:role/admin_role"),
    ("ptype:AWSService", "parn:arn:aws:iam::111122223333:role/system_service"),
]
PRINCIPALS_ATTACK = [
    ("ptype:IAMUser", "parn:arn:aws:iam::111122223333:user/unknown_user"),
    ("ptype:AssumedRole", "parn:arn:aws:sts::111122223333:assumed-role/stolen_token/session"),
]

NORMAL_WORKFLOWS = [
    ["sts:AssumeRole", "ecs:DescribeServices", "ecs:UpdateService", "s3:PutObject"],
    ["s3:ListBucket", "s3:GetObject", "athena:StartQueryExecution", "athena:GetQueryResults"],
    ["sts:GetCallerIdentity", "iam:ListUsers", "iam:GetPolicy", "cloudtrail:LookupEvents"],
    ["sts:AssumeRole", "iam:GetRole", "ec2:DescribeInstances", "s3:ListBucket", "s3:GetObject"],
]

ATTACK_CHAINS = {
    "priv_esc": ["sts:AssumeRole", "cloudtrail:StopLogging", "iam:PutRolePolicy", "sts:AssumeRole", "s3:GetObject"],
    "persistence": ["sts:AssumeRole", "iam:CreateUser", "iam:CreateAccessKey", "iam:AttachUserPolicy"],
    "exfil": ["sts:AssumeRole", "s3:ListBucket", "s3:GetObject", "s3:GetObject", "kms:Decrypt"],
    "resource_hijack": [
        "sts:AssumeRole",
        "ec2:DescribeInstances",
        "ec2:RunInstances",
        "ec2:CreateTags",
        "cloudwatch:PutMetricData",
    ],
}


@dataclass
class Event:
    action: str
    source: str
    principal_type: str
    principal_arn: str
    ip: str
    region: str
    ua: str
    resource: str
    time_bin: str


@dataclass
class DatasetArtifacts:
    sessions: List[dict]
    sessions_train: List[dict]
    sessions_test: List[dict]
    vocab: Dict[str, int]
    action_vocab: Dict[str, int]
    inv_action_vocab: Dict[int, str]
    pad_id: int
    mask_id: int
    unk_id: int
    x_obs: torch.Tensor
    x_full: torch.Tensor
    y_actions: torch.Tensor
    labels: torch.Tensor
    train_data: TensorDataset
    test_data: TensorDataset
    train_loader: DataLoader
    test_loader: DataLoader

    def encode_tokens(self, tokens: List[str]) -> List[int]:
        return [self.vocab.get(t, self.unk_id) for t in tokens]

    def encode_actions(self, actions: List[str]) -> List[int]:
        return [self.action_vocab.get(a, 0) for a in actions]


def maybe(p: float) -> bool:
    return random.random() < p


def blackout_event() -> Event:
    return Event(
        "<BLACKOUT>",
        "src:<BLACKOUT>",
        "ptype:<BLACKOUT>",
        "parn:<BLACKOUT>",
        "ip:<BLACKOUT>",
        "region:<BLACKOUT>",
        "ua:<BLACKOUT>",
        "res:<BLACKOUT>",
        "time:<BLACKOUT>",
    )


def action_to_source(action: str) -> str:
    namespace = action.split(":")[0]
    known = {
        "iam": "src:iam.amazonaws.com",
        "sts": "src:sts.amazonaws.com",
        "ec2": "src:ec2.amazonaws.com",
        "s3": "src:s3.amazonaws.com",
        "kms": "src:kms.amazonaws.com",
        "cloudtrail": "src:cloudtrail.amazonaws.com",
        "athena": "src:athena.amazonaws.com",
        "ecs": "src:ecs.amazonaws.com",
        "cloudwatch": "src:monitoring.amazonaws.com",
    }
    return known.get(namespace, "src:unknown.amazonaws.com")


def generate_event(action: str, attack: bool, step: int) -> Event:
    principal_type, principal_arn = random.choice(PRINCIPALS_ATTACK if attack else PRINCIPALS_NORMAL)
    ip = random.choice(IP_BUCKETS if attack else ["ip:corp", "ip:vpn"])
    region = "region:" + random.choice(REGIONS)
    ua = random.choice(UA_BUCKETS if attack else ["ua:awscli", "ua:console", "ua:sdk"])
    resource = random.choice(RESOURCE_BUCKETS)
    source = action_to_source(action)
    time_bin = f"time:t{step:02d}"

    if attack and action in ["cloudtrail:StopLogging", "iam:PutRolePolicy", "iam:CreateAccessKey"]:
        ip = random.choice(["ip:external", "ip:tor"])
        ua = random.choice(["ua:unknown", "ua:sdk"])

    return Event(action, source, principal_type, principal_arn, ip, region, ua, resource, time_bin)


def event_to_tokens(e: Event) -> List[str]:
    if e.action == "<BLACKOUT>":
        return [e.principal_type, e.principal_arn, "act:<BLACKOUT>", e.source, e.resource, e.ip, e.region, e.ua, e.time_bin]
    return [e.principal_type, e.principal_arn, f"act:{e.action}", e.source, e.resource, e.ip, e.region, e.ua, e.time_bin]


def session_to_tokens(events: List[Event]) -> List[str]:
    toks: List[str] = []
    for i in range(MAX_EVENTS):
        if i < len(events):
            toks.extend(event_to_tokens(events[i]))
        else:
            toks.extend([PAD] * TOKENS_PER_EVENT)
    return toks[:SEQ_LEN]


def session_to_actions(full_events: List[Event]) -> List[str]:
    actions: List[str] = []
    for i in range(MAX_EVENTS):
        if i < len(full_events):
            actions.append(full_events[i].action)
        else:
            actions.append("<PAD>")
    return actions


def inject_blackout(full_events: List[Event], blackout_len: Tuple[int, int] = (2, 3)) -> Tuple[List[Event], Tuple[int, int]]:
    length = len(full_events)
    if length < 5:
        return full_events, (-1, -1)

    blen = random.randint(*blackout_len)
    i = random.randint(1, max(1, length - blen - 1))
    j = min(length - 1, i + blen)

    observed = list(full_events)
    for k in range(i, j):
        observed[k] = blackout_event()
    return observed, (i, j)


def generate_session(mode: str = "normal", blackout_prob: float = 0.6) -> dict:
    if mode == "normal":
        chain = random.choice(NORMAL_WORKFLOWS)

        if maybe(0.005):
            chain = chain[:-1] + ["cloudtrail:StopLogging"] + chain[-1:]

        full = [generate_event(a, attack=False, step=i) for i, a in enumerate(chain)]
        return {"events": full, "full_events": full, "label": 0, "attack_type": "normal", "blackout": (-1, -1)}

    attack_type = random.choice(list(ATTACK_CHAINS.keys()))
    chain = ATTACK_CHAINS[attack_type]
    full = [generate_event(a, attack=True, step=i) for i, a in enumerate(chain)]

    if maybe(blackout_prob):
        obs, blk = inject_blackout(full)
    else:
        obs, blk = full, (-1, -1)

    return {"events": obs, "full_events": full, "label": 1, "attack_type": attack_type, "blackout": blk}


def build_dataset(n_normal: int = N_NORMAL, n_attack: int = N_ATTACK, batch_size: int = BATCH_SIZE) -> DatasetArtifacts:
    sessions = [generate_session("normal") for _ in range(n_normal)] + [generate_session("attack") for _ in range(n_attack)]
    random.shuffle(sessions)

    vocab = {s: i for i, s in enumerate(SPECIALS)}
    for session in sessions:
        for tok in session_to_tokens(session["events"]):
            if tok not in vocab:
                vocab[tok] = len(vocab)

    action_vocab = {"<PAD>": 0, "<BLACKOUT>": 1}
    for session in sessions:
        for action in session_to_actions(session["full_events"]):
            if action not in action_vocab:
                action_vocab[action] = len(action_vocab)
    inv_action_vocab = {v: k for k, v in action_vocab.items()}

    pad_id = vocab[PAD]
    mask_id = vocab[MASK]
    unk_id = vocab[UNK]

    x_obs = torch.tensor(
        [[vocab.get(t, unk_id) for t in session_to_tokens(s["events"])] for s in sessions],
        dtype=torch.long,
    )
    x_full = torch.tensor(
        [[vocab.get(t, unk_id) for t in session_to_tokens(s["full_events"])] for s in sessions],
        dtype=torch.long,
    )
    y_actions = torch.tensor(
        [[action_vocab.get(a, 0) for a in session_to_actions(s["full_events"])] for s in sessions],
        dtype=torch.long,
    )
    labels = torch.tensor([s["label"] for s in sessions], dtype=torch.long)

    n_total = len(sessions)
    n_train = int(0.8 * n_total)

    train_data = TensorDataset(x_obs[:n_train], x_full[:n_train], y_actions[:n_train], labels[:n_train])
    test_data = TensorDataset(x_obs[n_train:], x_full[n_train:], y_actions[n_train:], labels[n_train:])

    sessions_train = sessions[:n_train]
    sessions_test = sessions[n_train:]

    train_loader = DataLoader(train_data, batch_size=batch_size, shuffle=True)
    test_loader = DataLoader(test_data, batch_size=batch_size, shuffle=False)

    return DatasetArtifacts(
        sessions=sessions,
        sessions_train=sessions_train,
        sessions_test=sessions_test,
        vocab=vocab,
        action_vocab=action_vocab,
        inv_action_vocab=inv_action_vocab,
        pad_id=pad_id,
        mask_id=mask_id,
        unk_id=unk_id,
        x_obs=x_obs,
        x_full=x_full,
        y_actions=y_actions,
        labels=labels,
        train_data=train_data,
        test_data=test_data,
        train_loader=train_loader,
        test_loader=test_loader,
    )
