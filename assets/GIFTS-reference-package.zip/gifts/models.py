import torch
import torch.nn as nn


class TokenEncoder(nn.Module):
    def __init__(self, vocab_size: int, emb_dim: int, seq_len: int):
        super().__init__()
        self.emb = nn.Embedding(vocab_size, emb_dim)
        self.pos = nn.Embedding(seq_len + 1, emb_dim)

        layer = nn.TransformerEncoderLayer(
            d_model=emb_dim,
            nhead=4,
            dim_feedforward=emb_dim * 4,
            dropout=0.1,
            activation="gelu",
            batch_first=True,
        )
        self.encoder = nn.TransformerEncoder(layer, num_layers=2)
        self.ln = nn.LayerNorm(emb_dim)
        self.mlm = nn.Linear(emb_dim, vocab_size)

    def forward(self, x: torch.Tensor):
        batch_size, seq_len = x.shape
        pos_ids = torch.arange(seq_len, device=x.device).unsqueeze(0).repeat(batch_size, 1)
        hidden = self.emb(x) + self.pos(pos_ids)
        hidden = self.encoder(hidden)
        hidden = self.ln(hidden)
        logits = self.mlm(hidden)
        return logits, hidden


class SeqDiffusion(nn.Module):
    def __init__(self, latent_dim: int, max_events: int, diff_t: int):
        super().__init__()
        self.diff_t = diff_t
        self.pos = nn.Embedding(max_events, 16)
        self.inp = nn.Linear(latent_dim + 1 + 1 + 16, 64)
        layer = nn.TransformerEncoderLayer(
            d_model=64,
            nhead=4,
            dim_feedforward=256,
            dropout=0.1,
            activation="gelu",
            batch_first=True,
        )
        self.tr = nn.TransformerEncoder(layer, num_layers=2)
        self.out = nn.Linear(64, latent_dim)

    def forward(self, zt: torch.Tensor, t: torch.Tensor, known_mask: torch.Tensor):
        batch_size, max_events, _ = zt.shape
        t_feat = (t.float() / self.diff_t).view(batch_size, 1, 1).expand(batch_size, max_events, 1)
        m_feat = known_mask.float().view(batch_size, max_events, 1)
        pos_ids = torch.arange(max_events, device=zt.device).view(1, max_events).expand(batch_size, max_events)
        pos_feat = self.pos(pos_ids)
        x = torch.cat([zt, t_feat, m_feat, pos_feat], dim=-1)
        hidden = self.inp(x)
        hidden = self.tr(hidden)
        return self.out(hidden)


class ActionDecoder(nn.Module):
    def __init__(
        self,
        latent_dim: int,
        vocab_size: int,
        max_events: int,
        field_vocab_sizes: dict | None = None,
    ):
        super().__init__()
        self.pos = nn.Embedding(max_events, 16)
        self.inp = nn.Linear(latent_dim + 16, 96)
        layer = nn.TransformerEncoderLayer(
            d_model=96,
            nhead=4,
            dim_feedforward=256,
            dropout=0.1,
            activation="gelu",
            batch_first=True,
        )
        self.tr = nn.TransformerEncoder(layer, num_layers=2)
        self.out = nn.Linear(96, vocab_size)
        self.geom_proj = nn.Linear(96, latent_dim)
        self.field_heads = None
        if field_vocab_sizes:
            self.field_heads = nn.ModuleDict(
                {name: nn.Linear(96, size) for name, size in field_vocab_sizes.items()}
            )

    def forward(self, zseq: torch.Tensor, return_hidden: bool = False):
        batch_size, max_events, _ = zseq.shape
        pos_ids = torch.arange(max_events, device=zseq.device).view(1, max_events).expand(batch_size, max_events)
        pos_feat = self.pos(pos_ids)
        x = torch.cat([zseq, pos_feat], dim=-1)
        hidden = self.inp(x)
        hidden = self.tr(hidden)
        action_logits = self.out(hidden)
        field_logits = None
        if self.field_heads is not None:
            field_logits = {name: head(hidden) for name, head in self.field_heads.items()}

        if return_hidden:
            return action_logits, field_logits, hidden

        if field_logits is not None:
            return action_logits, field_logits
        return action_logits


def mask_inputs(x: torch.Tensor, pad_id: int, mask_id: int, p: float = 0.12):
    x = x.clone()
    mask = (torch.rand_like(x.float()) < p) & (x != pad_id)
    x[mask] = mask_id
    return x, mask


def pool_event_embeddings(hidden: torch.Tensor, max_events: int, tokens_per_event: int, emb_dim: int):
    batch_size = hidden.shape[0]
    h = hidden.view(batch_size, max_events, tokens_per_event, emb_dim)
    return h.mean(dim=2)


def linear_beta_schedule(steps: int, beta_start: float = 1e-4, beta_end: float = 2e-2):
    return torch.linspace(beta_start, beta_end, steps)


def q_sample(z0: torch.Tensor, t: torch.Tensor, eps: torch.Tensor, alpha_bar: torch.Tensor):
    abar_t = alpha_bar[t].view(-1, 1, 1)
    return torch.sqrt(abar_t) * z0 + torch.sqrt(1 - abar_t) * eps
