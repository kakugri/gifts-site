import argparse
import os


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description=(
            "Run the GIFTS reference pipeline and produce evaluation output plus "
            "a forensic markdown report."
        )
    )
    parser.add_argument(
        "--report-path",
        default="GIFTS_Forensic_Report_Inpaint.md",
        help="Path for the generated markdown forensic report.",
    )
    parser.add_argument(
        "--summary-path",
        help="Optional path for a machine-readable JSON run summary.",
    )
    parser.add_argument("--n-normal", type=int, help="Number of synthetic normal sessions.")
    parser.add_argument("--n-attack", type=int, help="Number of synthetic attack sessions.")
    parser.add_argument("--epochs-mlm", type=int, help="Masked-language-model training epochs.")
    parser.add_argument("--epochs-diff", type=int, help="Diffusion training epochs.")
    parser.add_argument("--epochs-dec", type=int, help="Decoder training epochs.")
    parser.add_argument("--diff-t", type=int, help="Number of diffusion steps.")
    parser.add_argument("--batch-size", type=int, help="Training batch size.")
    parser.add_argument("--heal-start-t", type=int, help="Start step for healing projection.")
    parser.add_argument(
        "--deep-on-flagged-only",
        action="store_true",
        help="Run the deep-path trust detector only on sessions flagged by the fast path.",
    )
    parser.add_argument(
        "--full-deep-eval",
        action="store_true",
        help="Run the deep-path trust detector on the full evaluation split.",
    )
    parser.add_argument(
        "--trust-sweep",
        action="store_true",
        help="Enable a small trust-parameter sweep after default trust evaluation.",
    )
    parser.add_argument(
        "--trust-sweep-starts",
        help="Comma-separated healing start steps for trust sweep, for example: 10,20,30",
    )
    parser.add_argument(
        "--trust-sweep-weights",
        help="Comma-separated geo:heal weights for trust sweep, for example: 1.0:1.0,1.5:0.5",
    )
    parser.add_argument(
        "--validate-session-file",
        metavar="PATH",
        help="Validate a GIFTS session-contract JSON or JSONL file and exit.",
    )
    parser.add_argument(
        "--convert-cloudtrail-jsonl",
        metavar="PATH",
        help="Convert CloudTrail-like JSONL records into the GIFTS session contract and exit.",
    )
    parser.add_argument(
        "--output",
        help="Output path for contract-conversion commands.",
    )
    return parser


def _set_env_if_present(value, env_name: str) -> None:
    if value is not None:
        os.environ[env_name] = str(value)


def apply_env_overrides(args: argparse.Namespace) -> None:
    mapping = {
        "n_normal": "GIFTS_N_NORMAL",
        "n_attack": "GIFTS_N_ATTACK",
        "epochs_mlm": "GIFTS_EPOCHS_MLM",
        "epochs_diff": "GIFTS_EPOCHS_DIFF",
        "epochs_dec": "GIFTS_EPOCHS_DEC",
        "diff_t": "GIFTS_DIFF_T",
        "batch_size": "GIFTS_BATCH_SIZE",
        "heal_start_t": "GIFTS_HEAL_START_T",
    }

    for attr_name, env_name in mapping.items():
        _set_env_if_present(getattr(args, attr_name), env_name)

    if args.deep_on_flagged_only and args.full_deep_eval:
        raise SystemExit("Choose either --deep-on-flagged-only or --full-deep-eval, not both.")

    if args.full_deep_eval:
        os.environ["GIFTS_DEEP_ON_FLAGGED_ONLY"] = "0"
    elif args.deep_on_flagged_only:
        os.environ["GIFTS_DEEP_ON_FLAGGED_ONLY"] = "1"

    if args.trust_sweep:
        os.environ["GIFTS_TRUST_SWEEP"] = "1"

    if args.trust_sweep_starts:
        os.environ["GIFTS_TRUST_SWEEP_STARTS"] = args.trust_sweep_starts

    if args.trust_sweep_weights:
        os.environ["GIFTS_TRUST_SWEEP_WEIGHTS"] = args.trust_sweep_weights


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.validate_session_file and args.convert_cloudtrail_jsonl:
        raise SystemExit("Choose either --validate-session-file or --convert-cloudtrail-jsonl, not both.")

    if args.validate_session_file:
        from .contracts import format_validation_result, validate_session_contract

        result = validate_session_contract(args.validate_session_file)
        print(format_validation_result(result))
        return 0 if result.is_valid else 1

    if args.convert_cloudtrail_jsonl:
        if not args.output:
            raise SystemExit("--convert-cloudtrail-jsonl requires --output.")

        from .contracts import convert_cloudtrail_jsonl_file

        output_path = convert_cloudtrail_jsonl_file(args.convert_cloudtrail_jsonl, args.output)
        print(f"Wrote session-contract file to {output_path}")
        return 0

    apply_env_overrides(args)

    from .pipeline import run_pipeline

    run_pipeline(report_path=args.report_path, summary_path=args.summary_path)
    return 0
