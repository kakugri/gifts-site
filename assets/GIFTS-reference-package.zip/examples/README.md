# GIFTS Examples

This folder contains the public adaptation examples for the `GIFTS` reference package.

## Files

- `cloudtrail_like_events.jsonl`
  - raw-event example showing how `CloudTrail`-style records can be grouped into sessions
- `gifts_session_contract_example.jsonl`
  - stable session-contract example showing the shape `GIFTS` expects after adaptation
- `GIFTS_output_report_example.md`
  - example markdown forensic report from a small reference run
- `GIFTS_output_summary_example.json`
  - example machine-readable run summary from a small reference run
- `GIFTS_workflow_findings_example.jsonl`
  - example workflow findings produced from the bundled session-contract file
- `GIFTS_workflow_findings_example.csv`
  - compact CSV version of the workflow findings
- `GIFTS_workflow_report_example.md`
  - analyst-readable workflow report from the same scoring pass

## Example workflow

Convert raw `CloudTrail`-like records into the `GIFTS` session contract:

```bash
python3 -m gifts \
  --convert-cloudtrail-jsonl examples/cloudtrail_like_events.jsonl \
  --output /tmp/gifts_sessions.jsonl
```

Validate the converted output:

```bash
python3 -m gifts --validate-session-file /tmp/gifts_sessions.jsonl
```

Validate the bundled contract example directly:

```bash
python3 -m gifts --validate-session-file examples/gifts_session_contract_example.jsonl
```

Score session-contract records into workflow findings:

```bash
python3 -m gifts \
  --score-session-file examples/gifts_session_contract_example.jsonl \
  --findings-path /tmp/gifts_findings.jsonl \
  --findings-csv /tmp/gifts_findings.csv \
  --workflow-report-path /tmp/gifts_workflow_report.md
```

Generate a markdown report plus JSON run summary:

```bash
python3 -m gifts \
  --n-normal 40 \
  --n-attack 8 \
  --epochs-mlm 1 \
  --epochs-diff 1 \
  --epochs-dec 1 \
  --diff-t 6 \
  --report-path /tmp/GIFTS_output_report.md \
  --summary-path /tmp/GIFTS_output_summary.json
```

## What these examples are for

These examples are meant to show:

- the current public input contract
- the adaptation path from raw identity events to GIFTS sessions
- how validated sessions can become workflow findings for triage or review
- how a technically capable reviewer could begin mapping real data into the reference package

They are not meant to claim that the current public package is ready for production ingestion as-is.
