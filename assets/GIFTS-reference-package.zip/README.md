# GIFTS Reference Package

This directory contains the current public reference implementation for the `Generative Identity Forensics and Trust System (GIFTS)`.

## What GIFTS is right now

At its current stage, `GIFTS` is best understood as a:

- research and evaluation pipeline
- public reference implementation
- technical review package for identity-assurance ideas

It is **not yet** best described as:

- a drop-in enterprise security product
- a production-ready `AWS` integration
- a polished framework with stable external APIs

## What the prototype currently demonstrates

The current implementation demonstrates four linked ideas:

1. synthetic identity-session generation for normal and attack-like behavior
2. latent-structure learning over identity-event sequences
3. diffusion-style reconstruction of missing or blacked-out action segments
4. trust and anomaly scoring over session behavior

The pipeline produces:

- printed evaluation metrics
- baseline and deep-path trust-detection metrics
- a markdown forensic reconstruction report for a blackout scenario
- an optional machine-readable JSON run summary

## What this package uses today

The prototype currently runs on:

- synthetic `CloudTrail`-style event sessions generated in `gifts/data.py`
- a transformer-based token encoder
- an `Isomap` latent projection
- a sequence diffusion model
- an action decoder with auxiliary field prediction

This means the package is useful today for:

- technical review
- research discussion
- reproducibility of the public prototype logic
- early evaluation by interested readers

It does **not** yet mean that a third party can point it at their production logs and deploy it as-is.

## Current adoption posture

The most accurate dissemination language right now is:

`GIFTS is a downloadable reference package for technical evaluation and adaptation.`

That is better than calling it a finished framework because it is both honest and still useful.

## Adoption modes

There are three realistic ways to use `GIFTS` today.

### 1. Review mode

Best for:

- researchers
- reviewers
- media or professional readers
- security engineers trying to understand the concept

What they do:

- read the paper and prototype report
- inspect the code structure
- run the demo pipeline locally
- review the generated forensic report

### 2. Evaluation mode

Best for:

- technically capable engineers
- labs
- collaborators exploring the method

What they do:

- run the package locally
- inspect the synthetic data assumptions
- modify the session generator or adapters
- test whether the logic transfers to their own event schema

### 3. Integration-preparation mode

Best for:

- future collaborators
- organizations interested in adaptation

What they would need next:

- a broader and more hardened input schema
- stronger adapters for real event sources
- model persistence and repeatable training flows
- better configuration surfaces
- clearer packaging and release versioning

## Dissemination mechanism

The current dissemination mechanism should be:

- publication and public site for explanation
- downloadable reference package for inspection and local execution
- later, a dedicated public code repository if ongoing public development becomes useful

In other words:

- the paper explains the method
- the site explains the context
- the reference package demonstrates the mechanics

## Input contract and adaptation path

The package now includes a public adaptation layer so outside readers can see how raw identity
events would be mapped into `GIFTS`.

Included:

- `docs/GIFTS_INPUT_CONTRACT.md`
- `docs/GIFTS_OUTPUT_CONTRACT.md`
- `docs/GIFTS_RESULT_INTERPRETATION.md`
- `docs/GIFTS_WORKFLOW_INTEGRATION.md`
- `examples/cloudtrail_like_events.jsonl`
- `examples/gifts_session_contract_example.jsonl`
- CLI validation and conversion commands

This makes the current adoption story more concrete:

- raw `CloudTrail`-like records can be grouped into sessions
- those sessions can be converted into the public `GIFTS` contract
- the contract can be validated before deeper experimentation
- validated sessions can be scored into workflow findings for analyst review
- run outputs can be preserved in a structured JSON summary for comparison and interpretation

Useful commands:

```bash
python3 -m gifts --validate-session-file examples/gifts_session_contract_example.jsonl
python3 -m gifts \
  --convert-cloudtrail-jsonl examples/cloudtrail_like_events.jsonl \
  --output /tmp/gifts_sessions.jsonl
python3 -m gifts \
  --score-session-file /tmp/gifts_sessions.jsonl \
  --findings-path /tmp/gifts_findings.jsonl \
  --findings-csv /tmp/gifts_findings.csv \
  --workflow-report-path /tmp/gifts_workflow_report.md
python3 -m gifts \
  --report-path /tmp/GIFTS_report.md \
  --summary-path /tmp/GIFTS_summary.json
```

## Workflow scoring mode

The new workflow scoring mode is the most practical current adoption path.

It lets an outside reviewer or security engineer bring a session-contract file and produce:

- JSONL findings for downstream tooling
- CSV findings for spreadsheet or SIEM-style review
- a markdown workflow report for analyst triage

Example:

```bash
python3 -m gifts \
  --score-session-file examples/gifts_session_contract_example.jsonl \
  --findings-path /tmp/gifts_findings.jsonl \
  --findings-csv /tmp/gifts_findings.csv \
  --workflow-report-path /tmp/gifts_workflow_report.md
```

This scoring layer is intentionally transparent. It is designed to support:

- SOC triage
- identity-control review
- incident reconstruction support
- red-team or tabletop evaluation

It should not be described as a production enforcement engine or final forensic authority.

## Quick start

From this directory, the fastest local run is:

```bash
python3 -m gifts --help
python3 -m gifts --report-path GIFTS_Forensic_Report_Inpaint.md
```

To make a faster smoke-test run:

```bash
python3 -m gifts \
  --n-normal 120 \
  --n-attack 24 \
  --epochs-mlm 1 \
  --epochs-diff 2 \
  --epochs-dec 1 \
  --diff-t 20
```

If you prefer the compatibility entry point:

```bash
python3 GIFTS.py --help
```

## Installation options

Minimal local install from this directory:

```bash
pip install -r requirements-cpu.txt
```

Editable package install:

```bash
pip install -e .
```

## Command-line controls

The CLI currently exposes the most useful prototype controls, including:

- report output path
- dataset size
- training-epoch counts
- diffusion steps
- batch size
- healing start step
- fast-path versus full deep evaluation
- optional trust-parameter sweep
- session-contract validation
- CloudTrail-like adaptation into the GIFTS session contract
- workflow scoring for external session-contract files
- JSONL, CSV, and markdown workflow-finding outputs
- optional JSON run-summary emission

Run:

```bash
python3 -m gifts --help
```

to see the available options.

## Current limitations

The current package still has important limitations:

- synthetic data rather than real public benchmark data
- only a reference-grade ingestion contract and example adapter, not a production ingestion layer
- no saved-model workflow or release artifacts
- no end-to-end deployment-ready integration
- no production hardening, service layer, or operator interface

## What would make GIFTS more adoptable next

The highest-value next upgrades are:

1. harden the public event schema into a broader, versioned compatibility contract
2. separate data generation from model execution more cleanly
3. add saved-model and reproducible evaluation commands
4. document outputs and intended operator use
5. publish a public-ready code bundle or repo as the canonical download target

## Bottom line

Right now, `GIFTS` is usable as a:

- reference package
- demo pipeline
- technical evaluation artifact

It is not yet best presented as a fully productized framework.

That is still a credible and useful public position, especially for research visibility and early adopter discussion.
